-- Seed api_endpoint and account_rate_limits (excludes postrefreshtoken / postgeneratetoken — always included separately)
-- updatedby / createdby: ffffffff-ffff-ffff-ffff-ffffffffffff

INSERT INTO api_endpoint (
  endpointid,
  endpointname,
  defaultratepermin,
  defaultrateperhour,
  defaultrateperday,
  maxvinspercall,
  max_history_days,
  ishistory,
  createdat,
  createdby,
  updatedat,
  updatedby
) VALUES
  ('getfleetvehicleinfo',            'Get fleet vehicle info (lite)',                    10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getfleetvehicleinfoadvanced',    'Get fleet vehicle info (advanced)',                  10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getfinanciervehicleinfo',        'Get financier vehicle info (lite)',                10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getfinanciervehicleinfoadvanced','Get financier vehicle info (advanced)',             10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getvehicleslist',                'Get vehicles list (legacy financier)',             10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getfinanciervehicles',           'Get financier vehicles (legacy)',            10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getvehiclebyvin',                'Get vehicle info by VIN (legacy)',                 10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('postfinancierfirecommand',       'Fire immobilizer command (legacy)',           5,  50,  500, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('postvehiclehistory',             'Request vehicle history report (legacy)',           5,  50,  500, 100, 30, true,  NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getvehiclehistorydownload',      'Download vehicle history report (legacy)',          5,  50,  500, 100, 30, true,  NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getvehicleslivedetails',         'Get vehicles live details (legacy)',    10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff'),
  ('getvehiclestripsummary',         'Get vehicles trip summary (legacy)',    10, 100, 1000, 100,  0, false, NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff', NOW(), 'ffffffff-ffff-ffff-ffff-ffffffffffff')
ON CONFLICT (endpointid) DO UPDATE SET
  endpointname       = EXCLUDED.endpointname,
  defaultratepermin  = EXCLUDED.defaultratepermin,
  defaultrateperhour = EXCLUDED.defaultrateperhour,
  defaultrateperday  = EXCLUDED.defaultrateperday,
  maxvinspercall     = EXCLUDED.maxvinspercall,
  max_history_days   = EXCLUDED.max_history_days,
  ishistory          = EXCLUDED.ishistory,
  updatedat          = NOW(),
  updatedby          = EXCLUDED.updatedby;
