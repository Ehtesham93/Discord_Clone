export default {
  pgdb: {
    host: "lmm.stgdb.nemo3",
    port: 5432,
    database: "lmmintellicar",
    schema: "devfmscoresch",
    user: "lmmintellicar_admin",
    password: "Z52DWfsAZIBtnOK",
  },
  redis: {
    host: "lmm-intellicar-cluster.t9kbdt.clustercfg.aps1.cache.amazonaws.com",
    port: 6379,
  },
  apiserver: {
    port: 10004,
  },
  authsvc: {
    url: "http://dev-nemo3-api-auth-svc.intellicar-frontend1:10004",
    createConsumerPath: "/api/v1/consumer",
    getUserTokenPath: "/api/v1/token",
    getAccountTokenPath: "/api/v1/account/token",
    invalidateTokenPath: "/api/v1/token/invalidate",
    getTokenPath: "/api/v1/token",
  },
  fmssvc: {
    url: "http://dev-nemo3-api-fms-svc.intellicar-frontend1:10004",
    basepath: "/api/v1/fms/apis",
    otherpaths: {"validatevins": "/validatevins", "vehicleinfo": "/vehicleinfo", "canstatus": "/vincanstatus", "gpsstatus": "/vingpsstatus", "vinlist": "/vehicle/list", "tripsbyvins": "/tripsbyvins"},
    getpermsbasepath: "/api/v1/fms/account",
    getpermpostfixpath: "/getmyaccountperms",
  },
  immobilizersvc: {
    url: "http://dev-nemo3-api-immobilization-svc.intellicar-frontend1:10004",
    basepath: "/api/v1/fms/immobilization",
    immobilizepath: "/vehicle/immobilize",
  },
  defaultuser: {
    password:
      "69f9f7c745883a32502dc7d9d67b16aaa09ea9d0b19de202555cf8e1b42be693",
  },
  logToConsole: false,
  sqs: {
    region: "ap-south-1",
    queueUrl: "https://sqs.ap-south-1.amazonaws.com/813183298904/report-download-queue",
  },
  reportDownload: {
    // used only to build download_url in response
    baseUrl: "https://stg-nemo.mahindralastmilemobility.com:2083",
    records3pathprefix: "lmm-intellicar/download-reports/"
  },
  s3: {
    region: "ap-south-1",
    defaultBucket: "lmm-intellicar",
  },
  apiToken: {
    tokenexpirytime: 60 * 60,
    refreshtokenexpirytime: 24 * 60 * 60,
  },
  invalidcases: {
    limit: 100,
  },
  ratelimit: {
    burstpersec: 5,
  },
  opensearch: {
    host:'https://vpc-nemo3-l67mgdj4bofbup4ttxj5jsaluu.ap-south-1.es.amazonaws.com:443',
    username:'admin',
    password:'Mahindra@123',
    index:'development-nemo3-api-svc-app-metrics',
  },

};
