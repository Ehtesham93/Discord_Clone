export default class RateLimitSvcDB {
  constructor(pgPoolI) {
    this.pgPoolI = pgPoolI;
  }

  async getAllEndpointDefaults() {
    const query = `
      SELECT endpointid, defaultratepermin, defaultrateperhour, defaultrateperday,
             maxvinspercall, max_history_days
      FROM api_endpoint
    `;
    const result = await this.pgPoolI.Query(query);
    return result.rows;
  }

  async getEndpointDefault(endpointid) {
    const query = `
      SELECT endpointid, defaultratepermin, defaultrateperhour, defaultrateperday,
             maxvinspercall, max_history_days
      FROM api_endpoint
      WHERE endpointid = $1
    `;
    const result = await this.pgPoolI.Query(query, [endpointid]);
    return result.rows[0] ?? null;
  }

  async getAccountRateLimits(accountid) {
    const query = `
      SELECT endpointid, ratepermin, rateperhour, rateperday,
             maxvinspercall, max_history_days
      FROM account_rate_limits
      WHERE accountid = $1
    `;
    const result = await this.pgPoolI.Query(query, [accountid]);
    return result.rows;
  }

  async getAccountEndpointLimit(accountid, endpointid) {
    const query = `
      SELECT endpointid, ratepermin, rateperhour, rateperday,
             maxvinspercall, max_history_days
      FROM account_rate_limits
      WHERE accountid = $1 AND endpointid = $2
    `;
    const result = await this.pgPoolI.Query(query, [accountid, endpointid]);
    return result.rows[0] ?? null;
  }
}
