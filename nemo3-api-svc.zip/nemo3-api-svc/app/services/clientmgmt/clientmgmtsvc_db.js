import { CONSOLE_MODULE_CODE } from "../../utils/constant.js";


export default class ClientmgmtSvcDB {
  constructor(pgPoolI, logger) {
    this.pgPoolI = pgPoolI;
    this.logger = logger;
  }

  async getAPIModules() {
    try {
      let query = `
        SELECT modulecode FROM module WHERE moduletype = 'api' AND isenabled = true
      `;
      let result = await this.pgPoolI.Query(query);
      return result.rows.map((row) => row.modulecode);
    }
    catch (error) {
      this.logger.error("getAPIModules failed", error);
      throw new Error("Could not retrieve API modules");
    }
  }
  
  async getRolePermsForAcc(accountid, userid) {
    try {
      let query = `
        SELECT fleetid FROM account_fleet WHERE accountid = $1 AND isroot = true
      `;
      let result = await this.pgPoolI.Query(query, [accountid]);
      if (result.rowCount === 0) {
        return null;
      }
      const rootfleetid = result.rows[0].fleetid;

      query = `
        SELECT permid FROM role_perm rp
        JOIN fleet_user_role fur
          ON rp.accountid = fur.accountid AND rp.roleid = fur.roleid
        WHERE rp.accountid = $1
          AND fur.accountid = $2
          AND fur.fleetid = $3
          AND fur.userid = $4
          AND rp.isenabled = true
      `;
      result = await this.pgPoolI.Query(query, [
        accountid,
        accountid,
        rootfleetid,
        userid,
      ]);
      const perms = result.rows.map((row) => row.permid);

      query = `
        SELECT mp.permid FROM module m
        JOIN module_perm mp ON m.moduleid = mp.moduleid
        WHERE m.modulecode = $1 AND m.isenabled = true AND mp.isenabled = true
      `;
      result = await this.pgPoolI.Query(query, [CONSOLE_MODULE_CODE]);
      const consolemgmtPerms = result.rows.map((row) => row.permid);

      return perms.filter((perm) => consolemgmtPerms.includes(perm));
    } catch (error) {
      this.logger.error("getRolePermsForAcc failed", error);
      throw new Error("Could not retrieve permissions");
    }
  }

  async getFleetIdForAcc(accountid) {
    try {
      let query = `
        SELECT fleetid FROM account_fleet WHERE accountid = $1 AND isroot = true
      `;
      let result = await this.pgPoolI.Query(query, [accountid]);
      if (result.rowCount === 0) {
        return null;
      }
      return result.rows[0].fleetid;
    }
    catch (error) {
      this.logger.error("getFleetIdForAcc failed", error);
      throw new Error("Could not retrieve fleet id");
    }
  }

  async getFmsRolePermsForAcc(accountid, userid) {
    try {
      let query = `
        SELECT fleetid FROM account_fleet WHERE accountid = $1 AND isroot = true
      `;
      let result = await this.pgPoolI.Query(query, [accountid]);
      if (result.rowCount === 0) {
        return null;
      }
      const rootfleetid = result.rows[0].fleetid;

      query = `
        SELECT permid FROM role_perm rp
        JOIN fleet_user_role fur
          ON rp.accountid = fur.accountid AND rp.roleid = fur.roleid
        WHERE rp.accountid = $1
          AND fur.accountid = $2
          AND fur.fleetid = $3
          AND fur.userid = $4
          AND rp.isenabled = true
      `;
      result = await this.pgPoolI.Query(query, [
        accountid,
        accountid,
        rootfleetid,
        userid,
      ]);
      const perms = result.rows.map((row) => row.permid);

      query = `
        SELECT mp.permid FROM module m
        JOIN module_perm mp ON m.moduleid = mp.moduleid
        WHERE m.modulecode = $1 AND m.isenabled = true AND mp.isenabled = true
      `;
      result = await this.pgPoolI.Query(query, ["apiservice"]);
      const consolemgmtPerms = result.rows.map((row) => row.permid);

      return perms.filter((perm) => consolemgmtPerms.includes(perm));
    } catch (error) {
      this.logger.error("getRolePermsForAcc failed", error);
      throw new Error("Could not retrieve permissions");
    }
  }

  async getApiClientByAccountId(accountid) {
    const query = `
      SELECT aac.accountid, aac.clientid, aac.clientsecret, aac.rotatedat, aac.label, aac.createdat, u1.displayname as createdby, aac.updatedat, u2.displayname as updatedby, aac.isenabled 
      FROM account_api_client aac 
      LEFT JOIN users u1 ON u1.userid = aac.createdby 
      LEFT JOIN users u2 ON u2.userid = aac.updatedby 
      WHERE aac.accountid = $1`;
    const result = await this.pgPoolI.Query(query, [accountid]);
    return result.rows[0] ?? null;
  }

  async CreateApiClient(clientdata, txclient) {
    try {
      const currenttime = new Date();
      const query = `
          INSERT INTO account_api_client (
            accountid, clientid, clientsecret, clientsecretold,
            rotatedat, label, createdat, createdby, updatedat, updatedby, isenabled
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *
        `;
      const result = await txclient.query(query, [
        clientdata.accountid,
        clientdata.clientid,
        clientdata.clientsecret,
        clientdata.clientsecret,
        currenttime,
        clientdata.label,
        currenttime,
        clientdata.userid,
        currenttime,
        clientdata.userid,
        true,
      ]);
      if (result.rowCount === 0) {
        throw new Error("Failed to create API client");
      }
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async RotateApiSecret(clientdata) {
    let [txclient, txnerr] = await this.pgPoolI.StartTransaction();
    if (txnerr) {
      throw txnerr;
    }
    try {
      const currenttime = new Date();
      const query = `
          UPDATE account_api_client SET clientsecret = $1, rotatedat = $2, clientsecretold = $3  WHERE accountid = $4 AND clientid = $5 RETURNING *
        `;
      const result = await txclient.query(query, [
        clientdata.clientsecret,
        currenttime,
        clientdata.clientsecretold,
        clientdata.accountid,
        clientdata.clientid,
      ]);
      if (result.rowCount === 0) {
        throw new Error("Failed to rotate API client secret");
      }
      let commiterr = await this.pgPoolI.TxCommit(txclient);
      if (commiterr) {
        throw commiterr;
      }
      return result.rows[0] ?? null;
    } catch (error) {
      let rollbackerr = await this.pgPoolI.TxRollback(txclient);
      if (rollbackerr) {
        this.logger.error("RotateApiSecret rollback failed", rollbackerr);
      }
      throw error;
    }
  }

  async DeleteApiClient(clientdata, txclient) {
    try {
      const query = `DELETE FROM account_api_client WHERE accountid = $1 AND clientid = $2 RETURNING *`;
      const result = await txclient.query(query, [
        clientdata.accountid,
        clientdata.clientid,
      ]);
      if (result.rowCount === 0) {
        throw new Error("Failed to delete API client");
      }
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }


  async getAccountAPIEndpoints(accountid) {
    try {
      const query = `
        WITH account_endpoints AS (
        SELECT DISTINCT
          SPLIT_PART(mp.permid, '.', 2) AS endpointid
        FROM account_subscription s
        LEFT JOIN package_module pm ON pm.pkgid = s.pkgid
        LEFT JOIN module m ON m.moduleid = pm.moduleid
        LEFT JOIN module_perm mp ON mp.moduleid = m.moduleid
        WHERE s.accountid = $1
          AND s.status = 'ACTIVE'
          AND m.moduletype = 'api'
          AND m.isenabled = true
          AND mp.isenabled = true
      )
      SELECT
        ae.endpointid,
        COALESCE(arl.ratepermin, ae.defaultratepermin)       AS ratepermin,
        COALESCE(arl.rateperhour, ae.defaultrateperhour)     AS rateperhour,
        COALESCE(arl.rateperday, ae.defaultrateperday)       AS rateperday,
        COALESCE(arl.maxvinspercall, ae.maxvinspercall)      AS maxvinspercall,
        COALESCE(arl.max_history_days, ae.max_history_days)  AS max_history_days,
        ae.ishistory,
        (arl.endpointid IS NOT NULL)                         AS has_custom_limits
      FROM account_endpoints ep
      INNER JOIN api_endpoint ae ON ae.endpointid = ep.endpointid
      LEFT JOIN account_rate_limits arl
        ON arl.accountid = $1
      AND arl.endpointid = ep.endpointid
      ORDER BY ae.endpointid;
      `;
      const endpointsresult = await this.pgPoolI.Query(query, [accountid]);
      return endpointsresult.rows;    
    } catch (error) {
      throw error;
    }
  }

  async getAPIEndpoints() {
    try {
      let query = `
      SELECT ae.endpointid, ae.endpointname, ae.defaultratepermin, ae.defaultrateperhour, ae.defaultrateperday, ae.maxvinspercall, ae.max_history_days, ae.ishistory, u.displayname as createdby, ae.createdat, u2.displayname as updatedby, ae.updatedat 
      FROM api_endpoint ae 
      LEFT JOIN users u ON u.userid = ae.createdby 
      LEFT JOIN users u2 ON u2.userid = ae.updatedby
      ORDER BY ae.updatedat DESC
      `;
      const endpointsresult = await this.pgPoolI.Query(query);
      return endpointsresult.rows;
    } catch (error) {
      throw error;
    }
  }

  async getEndpointDetails(endpointid) {
    try {
      let query = `SELECT ae.endpointid, ae.endpointname, ae.defaultratepermin, ae.defaultrateperhour, ae.defaultrateperday, ae.maxvinspercall, ae.max_history_days, ae.ishistory, u.displayname as createdby, ae.createdat, u2.displayname as updatedby, ae.updatedat 
      FROM api_endpoint ae 
      LEFT JOIN users u ON u.userid = ae.createdby 
      LEFT JOIN users u2 ON u2.userid = ae.updatedby
      WHERE ae.endpointid = $1`;
      const endpointresult = await this.pgPoolI.Query(query, [endpointid]);
      return endpointresult.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async updateAccountEndpoint(accountid, endpointid, body, userid) {
    try {
      const currenttime = new Date();
      let query = `UPDATE account_rate_limits SET ratepermin = $1, rateperday = $2, maxvinspercall = $3, max_history_days = $4, updatedat = $5, updatedby = $6 WHERE accountid = $7 AND endpointid = $8`;
      const result = await this.pgPoolI.Query(query, [
        body.ratepermin,
        body.rateperday,
        body.maxvinspercall,
        body.max_history_days,
        currenttime,
        userid,
        accountid,
        endpointid,
      ]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async deleteAccountEndpoint(accountid, endpointid) {
    try {
      let query = `DELETE FROM account_rate_limits WHERE accountid = $1 AND endpointid = $2`;
      const result = await this.pgPoolI.Query(query, [accountid, endpointid]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async createApiEndpoint(endpointData) {
    try {
      const currenttime = new Date();
      
      let query = `INSERT INTO api_endpoint (endpointid, endpointname, defaultratepermin, defaultrateperday, maxvinspercall, max_history_days, ishistory, createdat, createdby, updatedat, updatedby) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`;
      const result = await this.pgPoolI.Query(query, [
        endpointData.endpointid,
        endpointData.endpointname,
        endpointData.ratepermin,
        endpointData.rateperday,
        endpointData.maxvinspercall,
        endpointData.max_history_days,
        endpointData.ishistory,
        currenttime,
        endpointData.userid,
        currenttime,
        endpointData.userid,
      ]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async updateApiEndpoint(updateData) {
    try {
      const currenttime = new Date();
      let query = `UPDATE api_endpoint SET defaultratepermin = $1, defaultrateperday = $2, maxvinspercall = $3, max_history_days = $4, ishistory = $5, updatedat = $6, updatedby = $7 WHERE endpointid = $8 RETURNING *`;
      const result = await this.pgPoolI.Query(query, [
        updateData.ratepermin,
        updateData.rateperday,
        updateData.maxvinspercall,
        updateData.max_history_days,
        updateData.ishistory,
        currenttime,
        updateData.userid,
        updateData.endpointid,
      ]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async deleteApiEndpoint(endpointid) {
    try {
      let query = `DELETE FROM api_endpoint WHERE endpointid = $1 RETURNING *`;
      const result = await this.pgPoolI.Query(query, [endpointid]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async createDemoApiClient(demoClientData) {
    try {
      const currenttime = new Date();
      let query = `INSERT INTO demo_account_client (accountid, clientid, clientsecret, rotatedat, label, createdat, createdby) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`;
      const result = await this.pgPoolI.Query(query, [demoClientData.accountid, demoClientData.clientid, demoClientData.plainClientSecret, currenttime, demoClientData.label, currenttime, demoClientData.userid]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async rotateDemoApiSecret(accountid, clientid) {
    try {
      let query = `UPDATE demo_account_client SET clientsecret = $1, rotatedat = $2 WHERE accountid = $3 AND clientid = $4 RETURNING *`;
      const result = await this.pgPoolI.Query(query, [clientsecret, currenttime, accountid, clientid]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async getDemoApiClientByAccountId(accountid) {
    try {
      let query = `SELECT * FROM demo_account_client WHERE accountid = $1`;
      const result = await this.pgPoolI.Query(query, [accountid]);
      return result.rows[0] ?? null;
    } catch (error) {
      throw error;
    }
  }

  async getDemoAccountAPIEndpoints(accountid) {
    try {
      let query = `SELECT * FROM account_rate_limits WHERE accountid = $1`;
      const result = await this.pgPoolI.Query(query, [accountid]);
      return result.rows ?? null;
    } catch (error) {
      throw error;
    }
  }
}
