import ClientmgmtSvcDB from "./clientmgmtsvc_db.js";
import axios from "axios";
import config from "../../config/config.js";
import { PLATFORM_ACCOUNT_ID } from "../../utils/constant.js";

export default class ClientmgmtSvc {
  constructor(pgPoolI, logger) {
    this.pgPoolI = pgPoolI;
    this.logger = logger;
    this.config = config;
    this.clientmgmtSvcDB = new ClientmgmtSvcDB(pgPoolI, logger);
  }
  async GetConsolePerms(userid) {
    return this.clientmgmtSvcDB.getRolePermsForAcc(PLATFORM_ACCOUNT_ID, userid);
  }

  async getAPIModules() {
    return this.clientmgmtSvcDB.getAPIModules();
  }

  async GetAccountPerms(accountid, userid) {
    return this.clientmgmtSvcDB.getFmsRolePermsForAcc(accountid, userid);
  }

  async getFleetIdForAcc(accountid) {
    return this.clientmgmtSvcDB.getFleetIdForAcc(accountid);
  }

  async getApiClientByAccountId(accountid) {
    return this.clientmgmtSvcDB.getApiClientByAccountId(accountid);
  }

  async CreateApiClient(clientdata, txclient) {
    return this.clientmgmtSvcDB.CreateApiClient(clientdata, txclient);
  }

  async RotateApiSecret(clientdata) {
    return this.clientmgmtSvcDB.RotateApiSecret(clientdata);
  }

  async DeleteApiClient(clientdata, txclient) {
    return this.clientmgmtSvcDB.DeleteApiClient(clientdata, txclient);
  }

  async GetUserPerms(clientid) {
    return this.clientmgmtSvcDB.GetUserPerms(clientid);
  }

  async getAccountAPIEndpoints(accountid) {
    return this.clientmgmtSvcDB.getAccountAPIEndpoints(accountid);
  }

  async getAPIEndpoints() {
    return this.clientmgmtSvcDB.getAPIEndpoints();
  }

  async getEndpointDetails(endpointid) {
    return this.clientmgmtSvcDB.getEndpointDetails(endpointid);
  }

  async getEndpointMetrics(endpointid) {
    return this.clientmgmtSvcDB.getEndpointMetrics(endpointid);
  }

  async updateAccountEndpoint(accountid, endpointid, body, userid) {
    return this.clientmgmtSvcDB.updateAccountEndpoint(accountid, endpointid, body, userid);
  }

  async deleteAccountEndpoint(accountid, endpointid) {
    return this.clientmgmtSvcDB.deleteAccountEndpoint(accountid, endpointid);
  }

  async createApiEndpoint(endpointData) {
    return this.clientmgmtSvcDB.createApiEndpoint(endpointData);
  }

  async updateApiEndpoint(updateData) {
    return this.clientmgmtSvcDB.updateApiEndpoint(updateData);
  }

  async deleteApiEndpoint(endpointid) {
    return this.clientmgmtSvcDB.deleteApiEndpoint(endpointid);
  }

  async createDemoApiClient(demoClientData) {
    return this.clientmgmtSvcDB.createDemoApiClient(demoClientData);
  }

  async rotateDemoApiSecret(accountid, clientid) {
    return this.clientmgmtSvcDB.rotateDemoApiSecret(accountid, clientid);
  }

  async getDemoApiClientByAccountId(accountid) {
    return this.clientmgmtSvcDB.getDemoApiClientByAccountId(accountid);
  }

  async getDemoAccountAPIEndpoints(accountid) {
    return this.clientmgmtSvcDB.getDemoAccountAPIEndpoints(accountid);
  }

  async getRequestMetrics(metricsData) {
    try {
        const OPENSEARCH_HOST = this.config.opensearch.host;
        const INDEX = this.config.opensearch.index;
      
        const response = await axios.post(
          `${OPENSEARCH_HOST}/${INDEX}/_search`,
          {
            query: {
              bool: {
                must: [
                  { term: { "metric_name.keyword": "api_requests_by_account_total" } },
                  { term: { "labels.endpointid.keyword": metricsData.endpointid } },
                  { term: { "labels.accountid.keyword": metricsData.accountid } },
                  {
                    range: {
                      "@timestamp": { gte: metricsData.fromTime, lte: metricsData.toTime },
                    },
                  },
                ],
              },
            },
            sort: [{ "@timestamp": { order: "desc" } }],
            size: metricsData.size,
          },
          {
            headers: { "Content-Type": "application/json" },
            auth: {
              username: this.config.opensearch.username,
              password: this.config.opensearch.password,
            },
          }
        );
      
        const hits = response.data.hits.hits;
      
        return {
          endpointid: metricsData.endpointid,
          accountid: metricsData.accountid,
          MaxRateLimit: metricsData.maxRateLimit,
          totalRequests: hits.reduce((sum, hit) => sum + hit._source.value, 0),
          records: hits.map((hit) => ({
            timestamp: hit._source.timestamp,
            requestCount: hit._source.value,
          })),
        };
    } catch (error) {
      throw error;
    }
  }

}