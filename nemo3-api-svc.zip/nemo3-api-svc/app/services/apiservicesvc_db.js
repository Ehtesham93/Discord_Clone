import axios from "axios";
import { getTokenFromRequest } from "../utils/tokenutil.js";

export default class ApiServiceSvcDB {
  constructor(pgPoolI, logger, config) {
    this.pgPoolI = pgPoolI;
    this.logger = logger;
    this.config = config;
  }


  buildFmsAuthHeaders(req) {
    const token = getTokenFromRequest(req);
    const headers = {};
  
    if (req.headers.cookie) {
      headers.Cookie = req.headers.cookie;
    } else if (token) {
      headers.Cookie = `token=${token}`;
    }
  
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
  
    return headers;
  }

  asFmsList(value) {
    if (value == null) {
      return [];
    }
    if (Array.isArray(value)) {
      return value;
    }
    if (typeof value === "object") {
      return Object.values(value);
    }
    return [];
  }

  emptyVehicleFmsPayload(invalidVins = []) {
    return {
      validvins: [],
      invalidvins: invalidVins,
      vehicleinfo: [],
      canstatus: [],
      gpsstatus: [],
    };
  }

  async getVehicleDataFromFMS(vinList, req) {
    try {
      const fmsHeaders = this.buildFmsAuthHeaders(req);
      let queryParams = {
        accountid: req.accountid,
        vinno: vinList,
      };
      const validatevins = await axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.validatevins, {
        headers: fmsHeaders,
        params: queryParams,
      });
      if (validatevins.status !== 200) {
        throw {
          errcode: "ACCOUNT_VEHICLES_ERROR",
          message: "Error getting account vehicles",
        };
      }
      const data = validatevins.data?.data ?? {};
      const validVins = this.asFmsList(data.validvins);
      const invalidVins = this.asFmsList(data.invalidvins);
      
      if (validVins.length === 0) {
        return this.emptyVehicleFmsPayload(invalidVins);
      }
      queryParams = {
        accountid: req.accountid,
        vinno: validVins,
      };
      const [vehicleinfo, canstatus, gpsstatus] = await Promise.all([
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.vehicleinfo, {
          headers: fmsHeaders,
          params: queryParams,
        }),
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.canstatus, {
          headers: fmsHeaders,
          params: queryParams,
        }),
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.gpsstatus, {
          headers: fmsHeaders,
          params: queryParams,
        }),
      ]);
      if (vehicleinfo.status !== 200) {
        throw {
          errcode: "VEHICLE_INFO_ERROR",
          message: "Error getting vehicle info",
        };
      }
      if (canstatus.status !== 200) {
        throw {
          errcode: "CAN_STATUS_ERROR",
          message: "Error getting can status",
        };
      }
      if (gpsstatus.status !== 200) {
        throw {
          errcode: "GPS_STATUS_ERROR",
          message: "Error getting gps status",
        };
      }
      const vehicleinfoData = this.asFmsList(vehicleinfo.data?.data);
      const canstatusData = this.asFmsList(canstatus.data?.data);
      const gpsstatusData = this.asFmsList(gpsstatus.data?.data);


      return {
        validvins: validVins,
        vehicleinfo: vehicleinfoData,
        canstatus: canstatusData,
        gpsstatus: gpsstatusData,
        invalidvins: invalidVins,
      };
    } catch (error) {
      throw error;
    }
  }
  async getVehicleInfoFromFMS(searchtext, offset, limit, req) {
    try {
      const fmsHeaders = this.buildFmsAuthHeaders(req);
      let queryParams = {
        accountid: req.accountid,
        searchtext: searchtext,
        offset: offset,
        limit: limit,
      };
      const vehicleslist = await axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.vinlist, {
        headers: fmsHeaders,
        params: queryParams,
      });
      if (vehicleslist.status !== 200) {
        throw {
          errcode: "ACCOUNT_VEHICLES_ERROR",
          message: "Error getting account vehicles",
        };
      }
      const data = vehicleslist.data?.data ?? [];
      if (data?.totalcount === 0) {
        return {
          vinlist: [],
          vininfo: data,
          canstatus: {},
          gpsstatus: {},
        };
      }
      const vinList = (data?.vehicles ?? []).map(v => v.vinno).filter(Boolean);
      queryParams = {
        accountid: req.accountid,
        vinno: vinList,
      };
      const [canstatus, gpsstatus] = await Promise.all([
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.canstatus, {
          headers: fmsHeaders,
          params: queryParams,
        }),
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.gpsstatus, {
            headers: fmsHeaders,
          params: queryParams,
        }),
      ]);
      if (canstatus.status !== 200) {
        throw {
          errcode: "CAN_STATUS_ERROR",
          message: "Error getting can status",
        };
      }
      if (gpsstatus.status !== 200) {
        throw {
          errcode: "GPS_STATUS_ERROR",
          message: "Error getting gps status",
        };
      }
      const canstatusData = canstatus.data?.data ?? [];
      const gpsstatusData = gpsstatus.data?.data ?? [];
      return {
        vinlist: vinList,
        vininfo: data,
        canstatus: canstatusData,
        gpsstatus: gpsstatusData,
      };
    }catch (error) {
      throw error;
    }
  }

  async fireImmobilizerCommand(vin, command, req) {
    try {
      const fmsHeaders = this.buildFmsAuthHeaders(req);
      const data = await axios.post(this.config.immobilizersvc.url + this.config.immobilizersvc.basepath + this.config.immobilizersvc.immobilizepath, {
        vinno: vin,
        action: command,
      }, {
          headers: fmsHeaders,
      });
      if (data.status !== 200) {
        throw {
          errcode: "IMMOBILIZER_COMMAND_ERROR",
          message: "Oops! Something went wrong, Informed to tech team."
        };
      }
      return { message: "command fired successfully." };
    }catch (error) {
      throw error;
    }
  }

  async getLiveDetailsFromFMS(vinList, req) {
    try {
      const fmsHeaders = this.buildFmsAuthHeaders(req);
      let queryParams = {
        accountid: req.accountid,
        vinno: vinList,
      };
      const validatevins = await axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.validatevins, {
        headers: fmsHeaders,
        params: queryParams,
      });
      if (validatevins.status !== 200) {
        throw {
          errcode: "ACCOUNT_VEHICLES_ERROR",
          message: "Error validating vins",
        };
      }
      const data = validatevins.data?.data ?? [];
      const validVins = data.validvins;
      const invalidVins = data.invalidvins;
      
      if (validVins.length === 0) {
        return {
          errcode: "NO_VALID_VINS",
          message: "No valid vins found",
        };
      }
      queryParams = {
        accountid: req.accountid,
        vinno: validVins,
      };
      const [canstatus, gpsstatus, vehicleinfo] = await Promise.all([
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.canstatus, {
          headers: fmsHeaders,
          params: queryParams,
        }),
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.gpsstatus, {
          headers: fmsHeaders,
          params: queryParams,
        }),
        axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.vehicleinfo, {
          headers: fmsHeaders,
          params: queryParams,
        }),
      ]);
      if (vehicleinfo.status !== 200) {
        throw {
          errcode: "VEHICLE_INFO_ERROR",
          message: "Error getting vehicle info",
        };
      }
      if (canstatus.status !== 200) {
        throw {
          errcode: "CAN_STATUS_ERROR",
          message: "Error getting can status",
        };
      }
      if (gpsstatus.status !== 200) {
        throw {
          errcode: "GPS_STATUS_ERROR",
          message: "Error getting gps status",
        };
      }
      const canstatusData = canstatus.data?.data ?? [];
      const gpsstatusData = gpsstatus.data?.data ?? [];
      const vehicleinfoData = vehicleinfo.data?.data ?? [];

      return {
        validvins: validVins,
        canstatus: canstatusData,
        gpsstatus: gpsstatusData,
        invalidvins: invalidVins,
        vehicleinfo: vehicleinfoData,
      };
    } catch (error) {
      throw {
        errcode: "LIVE_DETAILS_ERROR",
        message: "Error getting live details",
      };
    }
  }

  async getTripSummaryFromFMS(vins, starttime, endtime, req) {
    try {
      const fmsHeaders = this.buildFmsAuthHeaders(req);
      let queryParams = {
        accountid: req.accountid,
        vinno: vins,
      };
      const validatevins = await axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.validatevins, {
        headers: fmsHeaders,
        params: queryParams,
      });
      if (validatevins.status !== 200) {
        throw {
          errcode: "ACCOUNT_VEHICLES_ERROR",
          message: "Error getting account vehicles",
        };
      }
      const data = validatevins.data?.data ?? [];
      const validVins = data.validvins;
      const invalidVins = data.invalidvins;
      if (validVins.length === 0){
        return {
          validvins: validVins,
          tripSummary: [],
          invalidvins: invalidVins,
        };
      }
      queryParams = {
        accountid: req.accountid,
        vinno: validVins,
        starttime: starttime,
        endtime: endtime,
      };
      const tripSummary = await axios.get(this.config.fmssvc.url + this.config.fmssvc.basepath + this.config.fmssvc.otherpaths.tripsbyvins, {
        headers: fmsHeaders,
        params: queryParams,
      });
      if (tripSummary.status !== 200) {
        throw {
          errcode: "TRIP_SUMMARY_ERROR",
          message: "Error getting trip summary",
        };
      }
      const tripSummaryData = tripSummary.data?.data ?? [];
      return {
        validvins: validVins,
        tripSummary: tripSummaryData,
        invalidvins: invalidVins,
      };
    } catch (error) {
      throw error;
    }
  }
  // accountid: accountid,
  // recordid: recordid,
  // recordtype: reportType,
  // recordstarttime: startEpochMs,
  // recordendtime: endEpochMs,
  // apikeyid: apikeyid,
  // status: "pending",
  // records3path: records3path,
  // createdat: currenttime,
  async createHistoryDownloadRecord({
    accountid,
    recordid,
    recordtype,
    recordstarttime,
    recordendtime,
    clientid,
    status,
    records3path,
    txclient
  }) {
    try {
      const currenttime = new Date().toISOString();

      const query = `
        INSERT INTO history_data_download
          (accountid, recordid, recordtype, clientid, status, records3path, createdat, recordstarttime, recordendtime)
        VALUES
          ($1, $2, $3, $4, $5, $6, $7, $8, $9);
      `;
    
      const result = await txclient.query(query, [
        accountid,
        recordid,
        recordtype,
        clientid,
        status,
        records3path,
        currenttime,
        recordstarttime,
        recordendtime,
      ]);
      return result.rowCount > 0;
    } catch (error) {
      throw error;
    }
  }

  async updateHistoryDownloadRecord(recordid, accountid, status, oldstatus) {
    try {
      const query = `UPDATE history_data_download SET status = $3 WHERE recordid = $1 AND accountid = $2 AND status = $4 RETURNING *` ;
      const result = await this.pgPoolI.Query(query, [recordid, accountid, status, oldstatus]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }

  async getHistoryDownloadRecordById(recordid, accountid) {
    try {
      const query = `SELECT * FROM history_data_download WHERE recordid = $1 AND accountid = $2`;
      const result = await this.pgPoolI.Query(query, [recordid, accountid]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }

  async getClientSecretByClientId(clientid) {
    try {
      let query = `SELECT accountid, clientid, clientsecret, clientsecretold, rotatedat FROM account_api_client WHERE clientid = $1`;
      let clientresult = await this.pgPoolI.Query(query, [clientid]);
      if (!clientresult || clientresult.rowCount === 0) {
        query = `SELECT accountid, clientid, clientsecret, rotatedat FROM demo_account_client WHERE clientid = $1`;
        let democlientresult = await this.pgPoolI.Query(query, [clientid]);
        if (!democlientresult || democlientresult.rowCount === 0) {
          throw {
            errcode: "CLIENT_NOT_FOUND",
            message: "Client not found",
          };
        }
        clientresult = democlientresult;
      }

      query = `SELECT * FROM account WHERE accountid = $1 AND isenabled = true AND isdeleted = false`;
      const accountresult = await this.pgPoolI.Query(query, [
        clientresult.rows[0].accountid,
      ]);
      if (accountresult.rowCount === 0) {
        throw {
          errcode: "ACCOUNT_NOT_FOUND",
          message: "Account not found",
        };
      }
      if (accountresult.rows[0].isenabled === false) {
        throw {
          errcode: "ACCOUNT_NOT_ENABLED",
          message: "Account is not enabled",
        };
      }
      if (accountresult.rows[0].isdeleted === true) {
        throw {
          errcode: "ACCOUNT_DELETED",
          message: "Account is deleted",
        };
      }
      return clientresult.rows[0];
    } catch (error) {
      throw error;
    }
  }

  async getDemoAccountCredentials(accountid) {
    try {
      let query = `SELECT dac.accountid, dac.clientid, dac.clientsecret, dac.rotatedat, dac.label, dac.createdat, u1.displayname as createdby
                FROM demo_account_client dac 
                LEFT JOIN users u1 ON u1.userid = dac.createdby 
                WHERE dac.accountid = $1`;
      const credentialsresult = await this.pgPoolI.Query(query, [accountid]);
      if (credentialsresult.rowCount === 0) {
        return null;
      }

      query = `SELECT * FROM account WHERE accountid = $1 AND isenabled = true AND isdeleted = false`;
      const accountresult = await this.pgPoolI.Query(query, [
        credentialsresult.rows[0].accountid,
      ]);
      if (accountresult.rowCount === 0) {
        return null;
      }
      if (accountresult.rows[0].isenabled === false) {
        return null;
      }
      if (accountresult.rows[0].isdeleted === true) {
        return null;
      }
      return credentialsresult.rows[0];
    } catch (error) {
      throw error;
    }
  }

  async getAccountidUsingClientId(clientid) {
    try {
      let query = `SELECT accountid FROM demo_account_client WHERE clientid = $1`;
      const demoresult = await this.pgPoolI.Query(query, [clientid]);
      if (demoresult.rowCount > 0) {
        return demoresult.rows[0].accountid;
      }

      query = `SELECT accountid FROM account_api_client WHERE clientid = $1`;
      const result = await this.pgPoolI.Query(query, [clientid]);
      if (result.rowCount === 0) {
        throw {
          errcode: "CLIENT_NOT_FOUND",
          message: "Client not found",
        };
      }
      return result.rows[0].accountid;
    } catch (error) {
      throw error;
    }
  }
}