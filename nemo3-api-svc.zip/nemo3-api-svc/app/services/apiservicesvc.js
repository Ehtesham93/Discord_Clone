import ApiServiceSvcDB from "./apiservicesvc_db.js";
import {
  formatEpochToDateTime,
  formatEpochToDurationMins,
} from "../utils/epochconverter.js";
import { ZEO, A301, TREO, T380 } from "../utils/constant.js";
import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";
import { downloadObjectFromS3Buffer } from "../utils/s3util.js";

export default class ApiServiceSvc {
  constructor(pgPoolI, logger, config) {
    this.pgPoolI = pgPoolI;
    this.logger = logger;
    this.config = config;
    this.apiServiceSvcDB = new ApiServiceSvcDB(pgPoolI, logger, config);
  }

  determineVehicleStatus = (canData, vehiclemodel) => {
    if (!canData) return "NA";
    const vehiclespeed = parseFloat(canData.vehiclespeed) || 0;
    const v_mode = parseInt(canData.v_mode) || 0;

    const vmodel = vehiclemodel.toLowerCase();
    if (vmodel.includes(ZEO)) {
      if (vehiclespeed > 5) {
        return "RUNNING";
      } else if (v_mode === 2) {
        let status = "CHARGING";
        if (parseInt(canData.bms_charger_plug_in_sts) === 2) {
          status = "FAST CHARGING";
        }
        return status;
      } else if (parseInt(canData.bms_charger_plug_in_sts) === 2) {
        return "PLUGGED";
      } else {
        return "IDLE";
      }
    } else if (vmodel.includes(A301) || vmodel.includes(T380)) {
      if (vehiclespeed > 5) {
        return "RUNNING";
      } else if (v_mode === 4) {
        let status = "CHARGING";
        if (parseInt(canData.bms_charger_plug_in_sts) === 2) {
          status = "FAST CHARGING";
        }
        return status;
      } else if (parseInt(canData.bms_charger_plug_in_sts) === 2) {
        return "PLUGGED";
      } else {
        return "IDLE";
      }
    } else {
      if (vehiclespeed > 5) {
        return "RUNNING";
      } else if (v_mode === 2) {
        return "CHARGING";
      } else if (parseInt(canData.bms_charger_plug_in_sts) === 2) {
        return "PLUGGED";
      } else {
        return "IDLE";
      }
    }
  };
  determineMode = (canData, vehiclemodel) => {
    if (!canData) return "NA";
    const vmodel = vehiclemodel.toLowerCase();
    const tcu_speedmode = parseInt(canData.tcu_speedmode) || 0;
    if (vmodel.includes(A301) || vmodel.includes(T380)) {
      if (tcu_speedmode === 0) {
        return "NEUTRAL";
      } else if (tcu_speedmode === 1) {
        return "REVERSE";
      } else if (tcu_speedmode === 2) {
        return "RANGE";
      } else if (tcu_speedmode === 3) {
        return "RACE";
      } else if (tcu_speedmode === 4) {
        return "LIMPHOME";
      } else if (tcu_speedmode === 5) {
        return "FAULT";
      } else if (tcu_speedmode === 6) {
        return "RIDE";
      } else {
        return "RANGE";
      }
    } else if (vmodel.includes(ZEO)) {
      if (tcu_speedmode === 1) {
        return "BOOST";
      } else {
        return "ECO";
      }
    } else {
      if (tcu_speedmode === 1) {
        return "BOOST";
      } else if (tcu_speedmode === 2) {
        return "ECOPLUS";
      } else {
        return "ECO";
      }
    }
  };

  processVinStatus = (candata, vehiclemodel, gpsstatus) => {
    if(!candata||!gpsstatus) return {};
    const vmodel = vehiclemodel.toLowerCase();
    const status = this.determineVehicleStatus(candata, vmodel);
    const mode = this.determineMode(candata, vmodel);
    const lastconnected =
      candata?.utctime > gpsstatus?.utctime
        ? candata?.utctime
        : gpsstatus?.utctime;
    let gear_position = "P";
    if (mode !== "NEUTRAL" && mode !== "REVERSE" && status === "RUNNING") {
      gear_position = "D";
    } else if (mode === "NEUTRAL") {
      gear_position = "N";
    } else if (mode === "REVERSE") {
      gear_position = "R";
    } else {
      gear_position = "P";
    }
    let key_status = "OFF";
    if (parseInt(candata.bms_in_keyon) === 1) {
      key_status = "ON";
    }
    return {
      vin: candata.vin,
      vehicle_status: status,
      odometer: candata.odometer,
      speed: candata.vehiclespeed,
      mode: mode,
      data_timestamp: candata.utctime,
      last_connected: lastconnected,
      gear_position: gear_position,
      key_status: key_status,
    };
  };

  processVinStatusLegacy = (candata, vehiclemodel, gpsstatus) => {
    if(!candata) return {};
    const vmodel = vehiclemodel.toLowerCase();
    const status = this.determineVehicleStatus(candata, vmodel);
    const mode = this.determineMode(candata, vmodel);
    const lastconnected =
      candata?.utctime > gpsstatus?.utctime
        ? candata?.utctime
        : gpsstatus?.utctime;
    let gear_position = "P";
    if (mode !== "NEUTRAL" && mode !== "REVERSE" && status === "RUNNING") {
      gear_position = "D";
    } else if (mode === "NEUTRAL") {
      gear_position = "N";
    } else if (mode === "REVERSE") {
      gear_position = "R";
    } else {
      gear_position = "P";
    }
    let key_status = "OFF";
    if (parseInt(candata.bms_in_keyon) === 1) {
      key_status = "ON";
    }
    const immo_status =
      parseInt(candata?.veh_immo_resp) === 2
        ? "drive_disabled"
        : "drive_enabled";
    return {
      vin: candata.vin,
      vehicle_status: status,
      odometer: candata.odometer,
      speed: candata.vehiclespeed,
      mode: mode,
      data_timestamp: candata.utctime,
      last_connected: lastconnected,
      gear_position: gear_position,
      key_status: key_status,
      immo_status: immo_status,
      motortemp: candata.motortemp,
      motorrpm: candata.e_motor_rpm,
    };
  };

  processVinBatteryStatus = (candata) => {
    if(!candata) return {};
    return {
      soc: candata.soc,
      dte: candata.dte,
      ttc: candata.battery_ttc,
      kwh: candata.kwh,
      temperature: candata.bms_batt_pack_temp,
      voltage: candata.bat_voltage,
    };
  };

  processVinLocation = (gpsstatus) => {
    if(!gpsstatus) return {};
    return {
      vin: gpsstatus.vin,
      lat: gpsstatus.latitude,
      long: gpsstatus.longitude,
      lat_dir: gpsstatus.latdir,
      long_dir: gpsstatus.longdir,
      gps_validity_flag: gpsstatus.valid,
      gps_speed: gpsstatus.speed,
      data_timestamp: gpsstatus.utctime,
    };
  };

  async GetFleetVehicleInfo(vinList, req) {
    try {
      const vehicledata = await this.apiServiceSvcDB.getVehicleDataFromFMS(
        vinList,
        req
      );
      let response = { valid_vins: {}, invalid_vins: vehicledata.invalidvins };
      let vehiclemodel = {};
      let vehiclecangpsjson = {};
      for (const vin of vehicledata.validvins) {
        response.valid_vins[vin] = {};
        vehiclecangpsjson[vin] = {};
      }
      for (const vininfo of vehicledata.vehicleinfo) {
        response.valid_vins[vininfo.vinno]["vehicleinfo"] = {
          vin: vininfo.vinno,
          license_plate: vininfo.license_plate,
          vehicle_model: vininfo.modelname,
          vehicle_variant: vininfo.modelvariant,
          color: vininfo.color,
        };
        vehiclemodel[vininfo.vinno] = vininfo.modelfamilycode;
      }
      for (const canstatus of vehicledata.canstatus) {
        vehiclecangpsjson[canstatus.vin]["canstatus"] = canstatus;
      }
      for (const gpsstatus of vehicledata.gpsstatus) {
        vehiclecangpsjson[gpsstatus.vin]["gpsstatus"] = gpsstatus;
      }
      for (const vin of vehicledata.validvins) {
        
        const vehiclestatus = this.processVinStatus(
          vehiclecangpsjson[vin]["canstatus"],
          vehiclemodel[vin],
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        const batterystatus = this.processVinBatteryStatus(
          vehiclecangpsjson[vin]["canstatus"]
        );
        const vehiclelocation = this.processVinLocation(
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        response.valid_vins[vin]["vehiclestatus"] = vehiclestatus;
        response.valid_vins[vin]["vehiclelocation"] = vehiclelocation;
        response.valid_vins[vin]["batterystatus"] = {
          soc: batterystatus.soc,
          dte: batterystatus.dte,
        };
      }

      return response;
    } catch (error) {
      throw error;
    }
  }
  async GetFleetVehicleInfoAdvanced(vinList, req) {
    try {
      const vehicledata = await this.apiServiceSvcDB.getVehicleDataFromFMS(
        vinList,
        req
      );
      let response = { valid_vins: {}, invalid_vins: vehicledata.invalidvins };
      let vehiclemodel = {};
      let vehiclecangpsjson = {};
      for (const vin of vehicledata.validvins) {
        response.valid_vins[vin] = {};
        vehiclecangpsjson[vin] = {};
      }
      for (const vininfo of vehicledata.vehicleinfo) {
        response.valid_vins[vininfo.vinno]["vehicleinfo"] = {
          vin: vininfo.vinno,
          license_plate: vininfo.license_plate,
          vehicle_model: vininfo.modelname,
          vehicle_variant: vininfo.modelvariant,
          color: vininfo.color,
        };
        vehiclemodel[vininfo.vinno] = vininfo.modelfamilycode;
      }
      for (const canstatus of vehicledata.canstatus) {
        vehiclecangpsjson[canstatus.vin]["canstatus"] = canstatus;
      }
      for (const gpsstatus of vehicledata.gpsstatus) {
        vehiclecangpsjson[gpsstatus.vin]["gpsstatus"] = gpsstatus;
      }
      for (const vin of vehicledata.validvins) {
        const vehiclestatus = this.processVinStatus(
          vehiclecangpsjson[vin]["canstatus"],
          vehiclemodel[vin],
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        const batterystatus = this.processVinBatteryStatus(
          vehiclecangpsjson[vin]["canstatus"]
        );
        const vehiclelocation = this.processVinLocation(
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        response.valid_vins[vin]["vehiclestatus"] = vehiclestatus;
        response.valid_vins[vin]["vehiclelocation"] = vehiclelocation;
        response.valid_vins[vin]["batterystatus"] = batterystatus;
      }

      return response;
    } catch (error) {
      throw error;
    }
  }
  async GetFinancierVehicleInfo(vinList, req) {
    try {
      const vehicledata = await this.apiServiceSvcDB.getVehicleDataFromFMS(
        vinList,
        req
      );
      let response = { valid_vins: {}, invalid_vins: vehicledata.invalidvins };
      for (const vin of vehicledata.validvins) {
        response.valid_vins[vin] = {};
      }
      for (const vininfo of vehicledata.vehicleinfo) {
        response.valid_vins[vininfo.vinno]["vehicleinfo"] = {
          vin: vininfo.vinno,
          license_plate: vininfo.license_plate,
          vehicle_model: vininfo.modelname,
          vehicle_variant: vininfo.modelvariant,
          color: vininfo.color,
        };
      }
      for (const gpsstatus of vehicledata.gpsstatus) {
        response.valid_vins[gpsstatus.vin]["vehiclelocation"] =
          this.processVinLocation(gpsstatus);
      }
      return response;
    } catch (error) {
      throw error;
    }
  }
  async GetFinancierVehicleInfoAdvanced(vinList, req) {
    try {
      const vehicledata = await this.apiServiceSvcDB.getVehicleDataFromFMS(
        vinList,
        req
      );
      let response = { valid_vins: {}, invalid_vins: vehicledata.invalidvins };
      let vehiclemodel = {};
      let vehiclecangpsjson = {};
      for (const vin of vehicledata.validvins) {
        response.valid_vins[vin] = {};
        vehiclecangpsjson[vin] = {};
      }
      for (const vininfo of vehicledata.vehicleinfo) {
        response.valid_vins[vininfo.vinno]["vehicleinfo"] = {
          vin: vininfo.vinno,
          license_plate: vininfo.license_plate,
          vehicle_model: vininfo.modelname,
          vehicle_variant: vininfo.modelvariant,
          color: vininfo.color,
        };
        vehiclemodel[vininfo.vinno] = vininfo.modelfamilycode;
      }
      for (const canstatus of vehicledata.canstatus) {
        vehiclecangpsjson[canstatus.vin]["canstatus"] = canstatus;
      }
      for (const gpsstatus of vehicledata.gpsstatus) {
        vehiclecangpsjson[gpsstatus.vin]["gpsstatus"] = gpsstatus;
      }
      for (const vin of vehicledata.validvins) {
        const vehiclestatus = this.processVinStatus(
          vehiclecangpsjson[vin]["canstatus"],
          vehiclemodel[vin],
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        const batterystatus = this.processVinBatteryStatus(
          vehiclecangpsjson[vin]["canstatus"]
        );
        const vehiclelocation = this.processVinLocation(
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        response.valid_vins[vin]["vehiclestatus"] = vehiclestatus;
        response.valid_vins[vin]["batterystatus"] = batterystatus;
        response.valid_vins[vin]["vehiclelocation"] = vehiclelocation;
      }
      return response;
    } catch (error) {
      throw error;
    }
  }
  async GetVehicleInfo(searchtext, offset, limit, req) {
    try {
      const vehicledata = await this.apiServiceSvcDB.getVehicleInfoFromFMS(
        searchtext,
        offset,
        limit,
        req
      );
      if (vehicledata.vininfo.totalcount === 0) {
        return {
          vininfo: vehicledata.vininfo,
          vehiclestatus: {},
          vehiclelocation: {},
          batterystatus: {},
        };
      }
      let response = {
        vininfo: vehicledata.vininfo,
        vehiclestatus: {},
        vehiclelocation: {},
        batterystatus: {},
      };
      let vehiclemodel = {};
      let vehiclecangpsjson = {};
      for (const vindata of vehicledata.vininfo.vehicles) {
        vehiclecangpsjson[vindata.vinno] = {};
        vehiclemodel[vindata.vinno] = vindata.modelfamilycode;
      }
      for (const canstatus of vehicledata.canstatus) {
        vehiclecangpsjson[canstatus.vin]["canstatus"] = canstatus;
      }
      for (const gpsstatus of vehicledata.gpsstatus) {
        vehiclecangpsjson[gpsstatus.vin]["gpsstatus"] = gpsstatus;
      }
      for (const vin of vehicledata.vinlist) {
        // console.log("candata:", vehiclecangpsjson[vin]["canstatus"]);
        // console.log("gpsstatus:", vehiclecangpsjson[vin]["gpsstatus"]);
        // console.log("vehiclemodel:", vehiclemodel[vin]);
        const vehiclestatus = this.processVinStatusLegacy(
          vehiclecangpsjson[vin]["canstatus"],
          vehiclemodel[vin],
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        const batterystatus = this.processVinBatteryStatus(
          vehiclecangpsjson[vin]["canstatus"]
        );
        const vehiclelocation = this.processVinLocation(
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        response.vehiclestatus[vin] = vehiclestatus;
        response.vehiclelocation[vin] = vehiclelocation;
        response.batterystatus[vin] = batterystatus;
      }
      return response;
    } catch (error) {
      throw error;
    }
  }
  async FireImmobilizerCommand(vin, command, req) {
    try {
      const data = await this.apiServiceSvcDB.fireImmobilizerCommand(
        vin,
        command,
        req
      );
      if (data.errcode) {
        return { errcode: data.errcode, message: data.message };
      }
      return data;
    } catch (error) {
      throw error;
    }
  }
  async GetLiveDetails(vins, req) {
    try {
      const data = await this.apiServiceSvcDB.getLiveDetailsFromFMS(vins, req);
      if (data.errcode) {
        return { errcode: data.errcode };
      }
      if (data.validvins.length === 0) {
        return { errcode: "NO_VALID_VINS", message: "No valid vins found" };
      }
      let response = [];
      let vehiclemodel = {};
      let vehiclecangpsjson = {};
      for (const vindata of data.vehicleinfo) {
        vehiclecangpsjson[vindata.vinno] = {};
        vehiclemodel[vindata.vinno] = vindata.modelfamilycode;
      }
      for (const canstatus of data.canstatus) {
        vehiclecangpsjson[canstatus.vin]["canstatus"] = canstatus;
      }
      for (const gpsstatus of data.gpsstatus) {
        vehiclecangpsjson[gpsstatus.vin]["gpsstatus"] = gpsstatus;
      }
      for (const vin of data.validvins) {
        const vehiclestatus = this.processVinStatusLegacy(
          vehiclecangpsjson[vin]["canstatus"],
          vehiclemodel[vin],
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        const batterystatus = this.processVinBatteryStatus(
          vehiclecangpsjson[vin]["canstatus"]
        );
        const vehiclelocation = this.processVinLocation(
          vehiclecangpsjson[vin]["gpsstatus"]
        );
        response.push({
          vinNumber: vin,
          vehicleStatus: vehiclestatus.vehicle_status,
          ignitionStatus: vehiclestatus.key_status,
          odometer: vehiclestatus.odometer,
          batteryVoltage: batterystatus.voltage,
          lastConnectedTime: formatEpochToDateTime(
            vehiclestatus.last_connected
          ),
          battertSOCpercentage: batterystatus.soc,
          speedKmph: vehiclestatus.speed,
          batteryRemainingEnergyKwh: batterystatus.kwh,
          motorTemperature: vehiclestatus.motortemp,
          motorRPM: vehiclestatus.motorrpm,
          lastGpsLocation: `${vehiclelocation.lat},${vehiclelocation.long}`,
        });
      }
      return response;
    } catch (error) {
      throw error;
    }
  }
  async GetTripSummary(vins, starttime, endtime, selectDate, req) {
    try {
      const tripdata = await this.apiServiceSvcDB.getTripSummaryFromFMS(
        vins,
        starttime,
        endtime,
        req
      );
      if (tripdata.errcode) {
        return { errcode: tripdata.errcode };
      }
      let data = []
      let tripnopervin = {};
      let tripstopMinspervin = {};
      let tripjson = {};
      for (const trip of tripdata.tripSummary) {
        if (!tripnopervin[trip.vin]) {
          tripnopervin[trip.vin] = 0;
          tripstopMinspervin[trip.vin] = 0;
          tripjson[trip.vin] = [];
        }
        tripnopervin[trip.vin]++;
        const tripDuration = trip.endtime - trip.starttime;
        const tripMoveTime = tripDuration - trip.idletime;
        const tripStopTimeMins = formatEpochToDurationMins(trip.idletime);
        tripstopMinspervin[trip.vin] += tripStopTimeMins;
        const tripMoveTimeMins = formatEpochToDurationMins(tripMoveTime);
        const tripDurationMins = formatEpochToDurationMins(tripDuration);
        const distanceTravelled = trip.endodo - trip.startodo;
        const minBatteryTemperature = Math.min(
          trip.startdata.bms_batt_pack_temp,
          trip.enddata.bms_batt_pack_temp
        );
        const energyConsumed = Math.abs(trip.endkwh - trip.startkwh);
        const eff =
          distanceTravelled && Number.isFinite(distanceTravelled) && distanceTravelled !== 0
            ? energyConsumed / distanceTravelled
            : null;
        tripjson[trip.vin].push({
          tripNo: tripnopervin[trip.vin],
          startLocation: `${trip.startlat},${trip.startlng}`,
          endLocation: `${trip.endlat},${trip.endlng}`,
          startDateTime: formatEpochToDateTime(trip.starttime),
          endDateTime: formatEpochToDateTime(trip.endtime),
          tripDurationMins: tripDurationMins,
          moveMins: tripMoveTimeMins,
          stopMins: tripStopTimeMins,
          startOdometer: trip.startodo,
          endOdometer: trip.endodo,
          distanceTraveledKm: distanceTravelled,
          startEnergyKwh: trip.startkwh,
          endEnergyKwh: trip.endkwh,
          energyConsumedKwh: Math.abs(trip.endkwh - trip.startkwh),
          energyEfficiencyWhpkm:
            eff,
          energyEfficiencyKmpwh:
            eff,
          maxBatteryTemperature: trip.maxbattemp,
          minBatteryTemperature: minBatteryTemperature,
          batteryTemperatureRise: trip.maxbattemp - minBatteryTemperature,
          maxBatteryCurrentAmp: trip.maxcurrent,
          maxSpeedKmph: trip.maxspeed,
          startBatteryVoltage: trip.startdata.bat_voltage,
          endBatteryVoltage: trip.enddata.bat_voltage,
          startSocPercentage: trip.startsoc,
          endSocPercentage: trip.endsoc,
        });
      }
      for (const vin of vins) {
        if (tripstopMinspervin[vin] > 0) {
          tripjson[vin].push({stopMins: tripstopMinspervin[vin]});
        }
        data.push({
          vinNumber: vin,
          data: tripjson[vin] ?? [],
        });
      }

      const anyTrips = (vins ?? []).some((vin) => (tripjson[vin]?.length ?? 0) > 0);
      return {
        resultCode: "0",
        resultText: "success",
        resultMessage: "Vehicle(s) trip detail retrieved successfully",
        selectDate: selectDate,
        data: anyTrips ? data : "No Records found.",
      };
    } catch (error) {
      throw error;
    }
  }

  async InitiateVehicleHistoryReport(accountid, recordid, vinList, startEpochMs, endEpochMs, clientid, reportType, records3path){
    const [txclient, err] = await this.pgPoolI.StartTransaction();
    if (err) {
      throw err;
    }
    try {
      const data = await this.apiServiceSvcDB.createHistoryDownloadRecord(
        {
          accountid: accountid,
          recordid: recordid,
          recordtype: reportType,
          recordstarttime: startEpochMs,
          recordendtime: endEpochMs,
          clientid: clientid,
          status: "pending",
          records3path: records3path,
          txclient: txclient,
        }
      );
      if (!data){
        throw new Error("Failed to create history download record");
      }
      // 2) Push SQS message
      const sqs = new SQSClient({ region: this.config.sqs.region });
      const messageBody = {
        accountid: accountid,
        recordid: recordid,
        vinList: vinList
      };
      const sqsResponse = await sqs.send(
        new SendMessageCommand({
          QueueUrl: this.config.sqs.queueUrl,
          MessageBody: JSON.stringify(messageBody),
        })
      );
      if (!sqsResponse){
        throw new Error("Failed to send SQS message");
      }
      // 3) Return download URL immediately
      const base = this.config.reportDownload.baseUrl;
      const downloadUrl = `${base}/financial/api/vehicles/${recordid}/download`;
      let commiterr = await this.pgPoolI.TxCommit(txclient);
      if (commiterr) {
        throw commiterr;
      }
      return {message: "Report generation intitated, please wait for sometime", downloadUrl: downloadUrl };
    } catch (error) {
      let rollbackerr = await this.pgPoolI.TxRollback(txclient);
      if (rollbackerr) {
        throw rollbackerr;
      }
      throw error;
    }
  }
  async GetHistoryDownloadStatus(recordid, accountid) {
    try {
      const row = await this.apiServiceSvcDB.getHistoryDownloadRecordById(recordid, accountid);
      if (!row) {
        return { errcode: "NO_DATA_FOUND", message: "No Data found." };
      }
      const { buffer, bucket, key } = await downloadObjectFromS3Buffer({ region: this.config.s3.region, records3path: row.records3path, defaultBucket: this.config.s3.defaultBucket });
      const filename = key.split("/").pop() || `${recordid}.csv`;
      return {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${filename}"`,
        },
        buffer,
      };
    } catch (error) {
      throw error;
    }
  }
  async UpdateHistoryReportStatus(recordid, accountid, status, oldstatus) {
    try {
      const data = await this.apiServiceSvcDB.updateHistoryDownloadRecord(recordid, accountid, status, oldstatus);
      if (!data) {
        throw new Error("Failed to update history download record");
      }
      return data;
    } catch (error) {
      throw error;
    }
  }

  async GetClientSecretByClientId(clientid) {
    return this.apiServiceSvcDB.getClientSecretByClientId(clientid);
  }
  async GetDemoAccountCredentials(accountid){
    return this.apiServiceSvcDB.getDemoAccountCredentials(accountid);
  }

  async GetAccountidUsingClientId(clientid){
    return this.apiServiceSvcDB.getAccountidUsingClientId(clientid);
  }
}
