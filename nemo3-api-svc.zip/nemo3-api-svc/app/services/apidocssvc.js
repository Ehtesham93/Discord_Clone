export default class ApiDocsSvc {
  constructor(pgPoolI, logger) {
    this.pgPoolI = pgPoolI;
    this.logger = logger;
  }

  async getAccountEndpoints(accountid) {
    const query = `
      SELECT DISTINCT
          mp.permid
      FROM account_subscription s
      LEFT JOIN package_module pm
          ON pm.pkgid = s.pkgid
      LEFT JOIN module m
          ON m.moduleid = pm.moduleid
      LEFT JOIN module_perm mp
          ON mp.moduleid = m.moduleid
      WHERE s.accountid = $1
        AND s.status = 'ACTIVE'
        AND m.moduletype = 'api'
        AND m.isenabled = true
        AND mp.isenabled = true;
    `;
    const result = await this.pgPoolI.Query(query, [accountid]);
    return result.rows.map((row) => ({
      endpointid: row.permid.split(".")[1],
    }));
  }
}
