import {
  APIResponseBadRequest,
  APIResponseForbidden,
  APIResponseInternalErr,
} from "./responseutil.js";
import { CheckUserPerms as checkUserPerms } from "../../lib/nemo3-lib-permcheck/checkperm.js";
import z from "zod";
import axios from "axios";
import config from "../config/config.js";
export { checkUserPerms as CheckUserPerms };

export function getPermissionAction(perm) {
  if (typeof perm !== "string") return null;
  const parts = perm.split(".");
  if (parts.length < 3) return null;
  return parts[1];
}

export function hasEndpointPermission(userPermissions, endpointAction) {
  if (!userPermissions?.length || !endpointAction) return false;
  if (
    userPermissions.includes("all.all.all") ||
    userPermissions.includes("apis.all.all")
  ) {
    return true;
  }
  for (const perm of userPermissions) {
    let endpoint = getPermissionAction(perm);
    if (endpoint === endpointAction) {
      return true;
    }
  }
  return false;
}

export function GetMyAPIServicePermissions(clientmgmtSvcI, logger) {
return async function getMyAPIServicePermissions(req, res, next) {
  try {

    const reqPath = req.path;
    if (reqPath.includes('/token') || reqPath.includes('/refreshtoken')) {
        next();
        return;
    }
      const fleetid = await clientmgmtSvcI.getFleetIdForAcc(req.accountid);
      if (!fleetid) {
        return APIResponseForbidden(req, res, "PERMISSIONS_DENIED", null, "Couldn't fetch fleetid for this account");
      }
      
      const schema = z.object({
          fleetid: z
          .string({ message: "fleetid is invalid or missing"})
          .uuid({ message: "fleetid is invalid or missing"})
      });
      schema.parse({ fleetid: String(fleetid) });
      const cookie = req.headers['Cookie'] || req.headers['cookie'];
      const path = `/api/v1/fms/account/fleet/${fleetid}/getmyperms`;
      const permissions = await internalApiCall(path, {}, 'GET', cookie, logger);
      const permissionsList = permissions.data.permissions;
      const permissionsByModule = permissions.data.permissionsbymodule;
      const isAdmin = permissionsList.includes('all.all.all');
      const apiServicePermissions = permissionsByModule.find(module => module.modulename === 'API Service');
      if (!apiServicePermissions) {
          return APIResponseForbidden(req, res, "PERMISSIONS_DENIED", null, "User does not have access to API service module");
      }
      req.permissions = { ...apiServicePermissions, admin: isAdmin };
      next();
  } catch (error) {
    logger.error("GetMyAPIServicePermissions error: ", error);
      if (error instanceof z.ZodError) {
          return APIResponseBadRequest(req, res, "INPUT_ERROR", null, error.issues[0].message);
      }
      return APIResponseForbidden(req, res, "PERMISSIONS_DENIED", null, error.toString());
  }
}
}

export function GetSubscriptionAPIServicePermissions(clientmgmtSvcI, logger) {
  return async function getSubscriptionAPIServicePermissions(req, res, next) {
    try {
      const reqPath = req.path;
      if (reqPath.includes('/token') || reqPath.includes('/refreshtoken')) {
        next();
        return;
      }

      let cookie = '';
      const authHeader = req.headers['authorization'] || req.headers['Authorization'];
      if (authHeader?.startsWith('Bearer ')) {
        cookie = `token=${authHeader.substring(7)}`;
      } else if (authHeader) {
        cookie = `token=${authHeader}`;
      }

      const path = '/api/v1/fms/subscription/details';
      const subscription = await internalApiCall(path, {}, 'GET', cookie, logger);
      const subscriptionData = subscription.data;
      const permissionsList = subscriptionData.perms || [];
      const modulecodes = subscriptionData.modulecodes || [];
      const isAdmin = permissionsList.includes('all.all.all');

      const apimodules = await clientmgmtSvcI.getAPIModules();
      const apiModulePerms = permissionsList.filter((perm) =>
        apimodules.some((code) => perm.startsWith(`${code}.`)),
      );

      const hasApiModuleAccess = apimodules.some(
        (code) =>
          modulecodes.includes(code) &&
          permissionsList.some((perm) => perm.startsWith(`${code}.`)),
      );

      if (!hasApiModuleAccess) {
        return APIResponseForbidden(
          req,
          res,
          "PERMISSIONS_DENIED",
          null,
          "User does not have access to any API module",
        );
      }

      req.permissions = {
        perms: apiModulePerms,
        modulename: 'API Service',
        admin: isAdmin,
      };
      next();
    } catch (error) {
      logger.error("GetSubscriptionAPIServicePermissions error: ", error);
      if (error instanceof z.ZodError) {
        return APIResponseBadRequest(req, res, "INPUT_ERROR", null, error.issues[0].message);
      }
      return APIResponseForbidden(req, res, "PERMISSIONS_DENIED", null, error.toString());
    }
  };
}

async function internalApiCall(path, body, method, cookie, logger) {
  try {
    const headers = {
        Accept: 'application/json',
        Cookie: cookie,
    };

    const response = await axios({
        url: `${config.fmssvc.url}${path}`,
        method: method,
        data: body,
        headers: headers,
    });
    return response.data;
} catch (error) {
    logger.error("InternalApiCall error: ", error);
    if (error.response && error.response.status === 401) {
        throw new Error(`Authentication failed: ${error.response.data?.exp || 'No credentials found'}`);
    }

    throw new Error(error.response.data?.msg || `Failed to connect, Try again later`);
}
}


export function GetMyPerms(clientmgmtSvcI, logger) {
  return async function getUserPermsHelper(req, res, next) {
    try {
      const userPerms = await clientmgmtSvcI.GetConsolePerms(req.userid);

      if (!userPerms?.length) {
        APIResponseForbidden(
          req, res, "CONSOLE_ACCESS_DENIED", null,
          "User does not have console access permissions"
        );
        return;
      }

      req.userperms = userPerms;
      next();
    } catch (error) {
      logger.error("GetUserPermsHelper error: ", error);
      APIResponseInternalErr(
        req, res, "CONSOLE_PERMISSION_CHECK_ERR",
        error.toString(), "Console permission check failed"
      );
    }
  };
}

