import { APIResponseBadRequest } from "./responseutil.js";
import { GetUnVerifiedClaims } from "./jwtutil.js";

const extractTokenFromCookieHeader = (cookieHeader) => {
  if (!cookieHeader) {
    return null;
  }

  if (cookieHeader.includes(";")) {
    for (const eachcookie of cookieHeader.split(";")) {
      const trimmed = eachcookie.trim();
      if (trimmed.startsWith("token=")) {
        return trimmed.substring(6);
      }
    }
    return null;
  }

  if (cookieHeader.startsWith("token=")) {
    return cookieHeader.substring(6);
  }

  return null;
};

const extractTokenFromAuthorizationHeader = (authHeader) => {
  if (!authHeader) {
    return null;
  }

  if (authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7);
  }

  return authHeader;
};

export const getTokenFromRequest = (req) => {
  return (
    extractTokenFromAuthorizationHeader(req.headers["Authorization"] || req.headers["authorization"]) ||
    extractTokenFromCookieHeader(req.headers["Cookie"] || req.headers["cookie"])
  );
};

export const AuthenticateUserTokenFromCookie = async (req, res, next) => {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      APIResponseBadRequest(
        req,
        res,
        "TOKEN_REQUIRED",
        {},
        "Token is required"
      );
      return;
    }

    let claims = await GetUnVerifiedClaims(token);
    if (!claims) {
      APIResponseBadRequest(req, res, "INVALID_TOKEN", {}, "Invalid token");
      return;
    }

    if (!claims.userid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "User ID is missing in token"
      );
      return;
    }

    req.userid = claims.userid;

    res.set({
      "Cache-Control": "no-store", // Stronger than no-cache
      Pragma: "no-cache",
      Expires: "0",
    });
    res.removeHeader("ETag");

    next();
  } catch (error) {
    this.logger.error("User token authentication failed", error);
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "User token validation failed"
    );
  }
};

const applyAccountSessionFromClaims = (req, res, claims) => {
  if (!claims.userid) {
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "User ID is missing in token"
    );
    return false;
  }

  if (!claims.accountid) {
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "Account ID is missing in token"
    );
    return false;
  }

  req.userid = claims.userid;
  req.accountid = claims.accountid;

  res.set({
    "Cache-Control": "no-store",
    Pragma: "no-cache",
    Expires: "0",
  });
  res.removeHeader("ETag");

  return true;
};

export const AuthenticateAccountTokenFromCookie = async (req, res, next) => {
  try {
    if (req.path.includes("/token")) {
      next();
      return;
    }

    const token = getTokenFromRequest(req);
    if (!token) {
      APIResponseBadRequest(
        req,
        res,
        "TOKEN_REQUIRED",
        {},
        "Token is required"
      );
      return;
    }

    let claims = await GetUnVerifiedClaims(token);
    if (!claims) {
      APIResponseBadRequest(req, res, "INVALID_TOKEN", {}, "Invalid token");
      return;
    }

    if (!applyAccountSessionFromClaims(req, res, claims)) {
      return;
    }

    next();
  } catch (error) {
    this.logger.error("Account token authentication failed", error);
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "Account token validation failed"
    );
  }
};


export const AuthenticateAccessToken = async (req, res, next) => {
  try {
    if (req.path.includes("/token")) {
      next();
      return;
    }

    const token = getTokenFromRequest(req);
    if (!token) {
      APIResponseBadRequest(
        req,
        res,
        "TOKEN_REQUIRED",
        {},
        "Token is required"
      );
      return;
    }

    let claims = await GetUnVerifiedClaims(token);
    if (!claims) {
      APIResponseBadRequest(req, res, "INVALID_TOKEN", {}, "Invalid token");
      return;
    }

    if (!claims.clientid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "Client ID is missing in token"
      );
      return;
    }

    if (!claims.accountid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "Account ID is missing in token"
      );
      return;
    }

    req.clientid = claims.clientid;
    req.accountid = claims.accountid;

    res.set({
      "Cache-Control": "no-store", // Stronger than no-cache
      Pragma: "no-cache",
      Expires: "0",
    });
    res.removeHeader("ETag");

    next();
  } catch (error) {
    this.logger.error("Account token authentication failed", error);
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "Account token validation failed"
    );
  }
};

export const AuthenticateUserToken = async (req, res, next) => {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      APIResponseBadRequest(
        req,
        res,
        "TOKEN_REQUIRED",
        {},
        "Token is required"
      );
      return;
    }

    let claims = await GetUnVerifiedClaims(token);
    if (!claims) {
      APIResponseBadRequest(req, res, "INVALID_TOKEN", {}, "Invalid token");
      return;
    }

    if (!claims.userid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "User ID is missing in token"
      );
      return;
    }

    req.userid = claims.userid;

    res.set({
      "Cache-Control": "no-store", // Stronger than no-cache
      Pragma: "no-cache",
      Expires: "0",
    });
    res.removeHeader("ETag");

    next();
  } catch (error) {
    this.logger.error("User token authentication failed", error);
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "User token validation failed"
    );
  }
};

export const AuthenticateAccountToken = async (req, res, next) => {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      APIResponseBadRequest(
        req,
        res,
        "TOKEN_REQUIRED",
        {},
        "Token is required"
      );
      return;
    }

    let claims = await GetUnVerifiedClaims(token);
    if (!claims) {
      APIResponseBadRequest(req, res, "INVALID_TOKEN", {}, "Invalid token");
      return;
    }

    if (!claims.userid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "User ID is missing in token"
      );
      return;
    }

    if (!claims.accountid) {
      APIResponseBadRequest(
        req,
        res,
        "INVALID_TOKEN",
        {},
        "Account ID is missing in token"
      );
      return;
    }

    req.userid = claims.userid;
    req.accountid = claims.accountid;

    res.set({
      "Cache-Control": "no-store", // Stronger than no-cache
      Pragma: "no-cache",
      Expires: "0",
    });
    res.removeHeader("ETag");

    next();
  } catch (error) {
    this.logger.error("Account token authentication failed", error);
    APIResponseBadRequest(
      req,
      res,
      "INVALID_TOKEN",
      {},
      "Account token validation failed"
    );
  }
};
