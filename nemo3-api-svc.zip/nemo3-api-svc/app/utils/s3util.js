import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

export function parseS3Location(records3path, defaultBucket) {
    if (!records3path || typeof records3path !== "string") {
      throw new Error("records3path is required");
    }
    records3path = "s3://"+records3path;
    const trimmed = records3path.trim();
    if (trimmed.startsWith("s3://")) {
      const rest = trimmed.slice(5);
      const slash = rest.indexOf("/");
      if (slash <= 0) throw new Error(`Invalid s3 URI: ${trimmed}`);
      const bucket = rest.slice(0, slash);
      const key = rest.slice(slash + 1).replace(/^\/+/, "");
      if (!key) throw new Error(`Invalid s3 URI (empty key): ${trimmed}`);
      return { bucket, key };
    }
    if (!defaultBucket) {
      throw new Error("records3path must be s3://bucket/key or defaultBucket must be set in config");
    }
    return { bucket: defaultBucket, key: trimmed.replace(/^\/+/, "") };
  }

export async function downloadObjectFromS3Buffer({ region, records3path, defaultBucket }) {
  const { bucket, key } = parseS3Location(records3path, defaultBucket);
  const client = new S3Client({ region });
  const out = await client.send(
    new GetObjectCommand({ Bucket: bucket, Key: key })
  );
  const chunks = [];
  for await (const chunk of out.Body) {
    chunks.push(chunk);
  }
  return { buffer: Buffer.concat(chunks), bucket, key };
}