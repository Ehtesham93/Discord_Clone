export function recordAccountApiMetrics(logger, endpointid, req, res) {
    if (!req.accountid || !logger?.getMetrics?.()) return;
    res.on("finish", () => {
      logger.getMetrics()
        .counter("api_requests_by_account_total", {
          labelNames: ["endpoint", "accountid", "endpointid"],
        })
        .inc(1, {
          endpoint: req.baseUrl + (req.route?.path || req.path),
          accountid: req.accountid,
          endpointid,
        });
    });
  }