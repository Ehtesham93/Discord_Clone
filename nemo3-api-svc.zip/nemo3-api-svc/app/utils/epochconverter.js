export const formatEpochToDateTime = (ms) => {
    if (!ms) return "";
    const formatter = new Intl.DateTimeFormat('en-IN', {
        timeZone: 'Asia/Kolkata',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hourCycle: 'h23',
      });
    
      ms = parseInt(ms);
      const parts = formatter.formatToParts(new Date(ms));
      const map = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
      const d = new Date(ms);
      const msPart = String(d.getMilliseconds()).padStart(3, "0");
      return `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}:${map.second}.${msPart}Z`;
  };

export const formatEpochToDuration = (milliseconds) => {
    if (!milliseconds || milliseconds <= 0) {
      return "0min";
    }

    const totalSeconds = Math.floor(milliseconds / 1000);
    const totalMinutes = Math.floor(totalSeconds / 60);
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const minutes = totalMinutes % 60;

    let str = "";
    if (days > 0) str += `${days}d `;
    if (hours > 0) str += `${hours}hr `;
    if (minutes > 0) str += `${minutes}min`;
    
    return str.trim() || "0min";
  };

  export const toFormattedString = (value) => {
    const absValue = Math.abs(value);
    const sign = value < 0 ? "-" : "";

    const trimmedTo2Decimals = (num) => {
      return parseFloat(num.toFixed(1)).toString();
    };

    if (absValue >= 1_000_000_000_000) {
      return `${sign}${trimmedTo2Decimals(value / 1_000_000_000_000)}T`;
    } else if (absValue >= 1_000_000_000) {
      return `${sign}${trimmedTo2Decimals(value / 1_000_000_000)}B`;
    } else if (absValue >= 1_000_000) {
      return `${sign}${trimmedTo2Decimals(value / 1_000_000)}M`;
    } else if (absValue >= 1_000) {
      return `${sign}${trimmedTo2Decimals(value / 1_000)}K`;
    } else {
      return trimmedTo2Decimals(value);
    }
  };

  export const formatLastUpdated = (isoString, { timeZone = 'UTC' } = {}) => {
    const date = new Date(isoString);
    if (isNaN(date)) throw new Error('Invalid date string');
  
    const fmt = new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
      timeZone,
    });
  
    const parts = Object.fromEntries(fmt.formatToParts(date).map(p => [p.type, p.value]));
    return `${parts.day} ${parts.month} ${parts.year} | ${parts.hour}:${parts.minute}:${parts.second}`;
  }

  export const ymdToStartEndEpochMsIST = (ymd) => {
    const [y, m, d] = ymd.split("-").map(Number);
  
    // 00:00:00.000 IST expressed in UTC milliseconds
    const start = Date.UTC(y, m - 1, d, 0, 0, 0, 0) - (5 * 60 + 30) * 60 * 1000;
  
    // 23:59:59.999 IST
    const end = start + 24 * 60 * 60 * 1000 - 1;
  
    return { startEpochMs: start, endEpochMs: end };
  };

  export const mdyToStartEndEpochMsIST = (mdy) => {
    const [m, d, y] = mdy.split("-").map(Number);
  
    // 00:00:00.000 IST expressed in UTC milliseconds
    const start = Date.UTC(y, m - 1, d, 0, 0, 0, 0) - (5 * 60 + 30) * 60 * 1000;
  
    // 23:59:59.999 IST
    const end = start + 24 * 60 * 60 * 1000 - 1;
  
    return { startEpochMs: start, endEpochMs: end };
  };
  export const formatEpochToDurationMins = (milliseconds) => {
    if (!milliseconds || milliseconds <= 0) {
      return 0;
    }
    return Math.floor(milliseconds / 60000);
  };