import FabErr from "./faberr.js";
import RateLimitSvcDB from "../services/ratelimitsvc_db.js";
import {
  APIResponseTooManyRequests,
  APIResponseTooManyRequestsCustom,
} from "./responseutil.js";

export const ErrRateLimit = new FabErr(
  "RATE_LIMIT_EXCEEDED",
  null,
  "rate limit exceeded"
);
export const ErrInvalidCaseLimit = new FabErr(
  "INVALID_CASE_LIMIT_EXCEEDED",
  null,
  "invalid case rate limit exceeded"
);

const CONFIG_TTL_SEC = 3600;
const DEFAULT_CONFIG_KEY = "default.ratelimit.config";
const WINDOW_TTL = { min: 60, hour: 3600, day: 86400, burst: 1 };
const INVALID_CASE_TTL_SEC = 86400;

const RATE_LIMIT_RESERVE_LUA = `
local function try_reserve(key, limit, ttl)
  local lim = tonumber(limit)
  if lim == nil or lim <= 0 then
    return 1, 0
  end
  local current = redis.call('INCR', key)
  if current == 1 then
    redis.call('EXPIRE', key, tonumber(ttl))
  end
  if current > lim then
    redis.call('DECR', key)
    return 0, 0
  end
  return 1, 1
end

local reserved = {}
local function rollback()
  for i = 1, #reserved do
    redis.call('DECR', reserved[i])
  end
end

local ok, did = try_reserve(KEYS[1], ARGV[1], ARGV[2])
if ok == 0 then return 0 end
if did == 1 then table.insert(reserved, KEYS[1]) end

ok, did = try_reserve(KEYS[2], ARGV[3], ARGV[4])
if ok == 0 then rollback() return 0 end
if did == 1 then table.insert(reserved, KEYS[2]) end

ok, did = try_reserve(KEYS[3], ARGV[5], ARGV[6])
if ok == 0 then rollback() return 0 end
if did == 1 then table.insert(reserved, KEYS[3]) end

ok, did = try_reserve(KEYS[4], ARGV[7], ARGV[8])
if ok == 0 then rollback() return 0 end

return 1
`;

const RATE_LIMIT_RELEASE_LUA = `
local function release(key, limit)
  local lim = tonumber(limit)
  if lim == nil or lim <= 0 then
    return
  end
  local current = tonumber(redis.call('GET', key) or '0')
  if current > 0 then
    redis.call('DECR', key)
  end
end

release(KEYS[1], ARGV[1])
release(KEYS[2], ARGV[3])
release(KEYS[3], ARGV[5])
release(KEYS[4], ARGV[7])
return 1
`;

const INVALID_CASE_RESERVE_LUA = `
local limit = tonumber(ARGV[1])
local ttl = tonumber(ARGV[2])
if limit == nil or limit <= 0 then
  return 1
end
local current = redis.call('INCR', KEYS[1])
if current == 1 then
  redis.call('EXPIRE', KEYS[1], ttl)
end
if current > limit then
  redis.call('DECR', KEYS[1])
  return 0
end
return 1
`;

function rowToLimitConfig(row, isDefault = false) {
  if (!row) return null;
  if (isDefault) {
    return {
      ratepermin: row.defaultratepermin,
      rateperhour: row.defaultrateperhour,
      rateperday: row.defaultrateperday,
      maxvinspercall: row.maxvinspercall,
      max_history_days: row.max_history_days,
    };
  }
  return {
    ratepermin: row.ratepermin,
    rateperhour: row.rateperhour,
    rateperday: row.rateperday,
    maxvinspercall: row.maxvinspercall,
    max_history_days: row.max_history_days,
  };
}

function rowsToConfigMap(rows, isDefault = false) {
  const map = {};
  for (const row of rows) {
    map[row.endpointid] = rowToLimitConfig(row, isDefault);
  }
  return map;
}

export function getMaxVinsPerCall(req, fallback = 100) {
  const limit = req.rateLimitConfig?.maxvinspercall;
  if (limit != null && limit > 0) return limit;
  return fallback;
}

export default class RateLimitSvc {
  constructor(redisSvc, pgPoolI, logger, config) {
    this.redisSvc = redisSvc;
    this.db = new RateLimitSvcDB(pgPoolI);
    this.logger = logger;
    this.config = config;
    this.invalidCaseLimit = config.invalidcases?.limit ?? 100;
    this.burstLimit = config.ratelimit?.burstpersec ?? 5;
  }

  accountConfigKey(accountid) {
    return `${accountid}.ratelimit.config`;
  }

  rateCounterKeys(accountid, endpointid) {
    const tag = `{${accountid}}`;
    const base = `${tag}:rate:${endpointid}`;
    return {
      min: `${base}:min`,
      hour: `${base}:hour`,
      day: `${base}:day`,
      burst: `${base}:burst`,
    };
  }

  invalidCaseKey(accountid) {
    return `{${accountid}}:rate:invalidcases`;
  }

  async getDefaultConfigMap() {
    const [cached, err] = await this.redisSvc.get(DEFAULT_CONFIG_KEY);
    if (err) {
      this.logger.error("rate limit default config redis get error", err);
    }
    if (cached) {
      try {
        return [JSON.parse(cached), null];
      } catch (e) {
        this.logger.warn("rate limit default config parse error", e);
      }
    }

    const rows = await this.db.getAllEndpointDefaults();
    const map = rowsToConfigMap(rows, true);
    const [, setErr] = await this.redisSvc.set(
      DEFAULT_CONFIG_KEY,
      JSON.stringify(map),
      CONFIG_TTL_SEC
    );
    if (setErr) {
      this.logger.error("rate limit default config redis set error", setErr);
    }
    return [map, null];
  }

  async getAccountConfigMap(accountid) {
    const key = this.accountConfigKey(accountid);
    const [cached, err] = await this.redisSvc.get(key);
    if (err) {
      this.logger.error("rate limit account config redis get error", err);
    }
    if (cached) {
      try {
        return [JSON.parse(cached), null];
      } catch (e) {
        this.logger.warn("rate limit account config parse error", e);
      }
    }

    const rows = await this.db.getAccountRateLimits(accountid);
    const map = rowsToConfigMap(rows, false);
    const [, setErr] = await this.redisSvc.set(
      key,
      JSON.stringify(map),
      CONFIG_TTL_SEC
    );
    if (setErr) {
      this.logger.error("rate limit account config redis set error", setErr);
    }
    return [map, null];
  }

  resolveEndpointLimits(defaultMap, accountMap, endpointid) {
    const accountCfg = accountMap?.[endpointid];
    const defaultCfg = defaultMap?.[endpointid];
    if (!accountCfg && !defaultCfg) {
      return null;
    }
    const pick = (field) => {
      const accountVal = accountCfg?.[field];
      if (accountVal != null && accountVal > 0) return accountVal;
      return defaultCfg?.[field] ?? 0;
    };
    return {
      ratepermin: pick("ratepermin"),
      rateperhour: pick("rateperhour"),
      rateperday: pick("rateperday"),
      maxvinspercall: pick("maxvinspercall"),
      max_history_days: pick("max_history_days"),
    };
  }

  async getEndpointLimits(accountid, endpointid) {
    const [defaultMap] = await this.getDefaultConfigMap();
    const [accountMap] = await this.getAccountConfigMap(accountid);
    let limits = this.resolveEndpointLimits(defaultMap, accountMap, endpointid);

    if (!limits) {
      const row = await this.db.getEndpointDefault(endpointid);
      if (row) {
        limits = rowToLimitConfig(row, true);
      } else {
        const accountRow = await this.db.getAccountEndpointLimit(
          accountid,
          endpointid
        );
        if (accountRow) {
          limits = rowToLimitConfig(accountRow, false);
        }
      }
    }
    return limits;
  }

  hasActiveLimits(limits) {
    if (!limits) return this.burstLimit > 0;
    return (
      limits.ratepermin > 0 ||
      limits.rateperhour > 0 ||
      limits.rateperday > 0 ||
      this.burstLimit > 0
    );
  }

  rateLimitArgs(limits) {
    return [
      limits?.ratepermin ?? 0,
      WINDOW_TTL.min,
      limits?.rateperhour ?? 0,
      WINDOW_TTL.hour,
      limits?.rateperday ?? 0,
      WINDOW_TTL.day,
      this.burstLimit,
      WINDOW_TTL.burst,
    ];
  }

  async reserveRateLimit(accountid, endpointid, limits) {
    const keys = this.rateCounterKeys(accountid, endpointid);
    const [result, err] = await this.redisSvc.evalScript(
      RATE_LIMIT_RESERVE_LUA,
      [keys.min, keys.hour, keys.day, keys.burst],
      this.rateLimitArgs(limits)
    );
    if (err) {
      this.logger.error("rate limit reserve lua error", err);
      return [true, null];
    }
    return [result === 1, null];
  }

  async releaseRateLimit(accountid, endpointid, limits) {
    const keys = this.rateCounterKeys(accountid, endpointid);
    const [, err] = await this.redisSvc.evalScript(
      RATE_LIMIT_RELEASE_LUA,
      [keys.min, keys.hour, keys.day, keys.burst],
      this.rateLimitArgs(limits)
    );
    if (err) {
      this.logger.error("rate limit release lua error", err);
    }
  }

  async reserveInvalidCase(accountid) {
    const key = this.invalidCaseKey(accountid);
    const [result, err] = await this.redisSvc.evalScript(
      INVALID_CASE_RESERVE_LUA,
      [key],
      [this.invalidCaseLimit, INVALID_CASE_TTL_SEC]
    );
    if (err) {
      this.logger.error("invalid case rate limit reserve lua error", err);
      return [true, null];
    }
    return [result === 1, null];
  }

  shouldKeepRateReservation(statusCode) {
    return statusCode >= 200 && statusCode < 300;
  }

  respondTooManyRequests(req, res, errcode, message) {
    req._skipInvalidCaseRateLimit = true;
    if (this.usesCustomResponse(req)) {
      return APIResponseTooManyRequestsCustom(req, res, { message });
    }
    return APIResponseTooManyRequests(req, res, errcode, null, message);
  }

  usesCustomResponse(req) {
    const base = req.baseUrl || "";
    return base === "/financial/api" || base === "/api";
  }

  wrapResponseForRateLimiting(req, res) {
    if (!req.accountid || res._rateLimitResponseWrapped) return;
    res._rateLimitResponseWrapped = true;
    const svc = this;
    const origSend = res.send.bind(res);

    res.send = function (body) {
      const statusCode = res.statusCode;

      if (
        statusCode === 400 &&
        req.accountid &&
        !req._skipInvalidCaseRateLimit
      ) {
        return svc
          .reserveInvalidCase(req.accountid)
          .then(([allowed]) => {
            if (!allowed) {
              return svc.respondTooManyRequests(
                req,
                res,
                "INVALID_CASE_LIMIT_EXCEEDED",
                "Invalid case rate limit exceeded"
              );
            }
            return origSend(body);
          })
          .catch((e) => {
            svc.logger.error("invalid case response guard error", e);
            return origSend(body);
          });
      }

      if (
        req._rateLimitReserved &&
        !svc.shouldKeepRateReservation(statusCode)
      ) {
        const { accountid, endpointid, limits } = req._rateLimitReserved;
        return svc
          .releaseRateLimit(accountid, endpointid, limits)
          .then(() => origSend(body))
          .catch((e) => {
             svc.logger.error("rate limit release on response error", e);
            return origSend(body);
          });
      }

      return origSend(body);
    };
  }

  async enforceEndpointRateLimit(req, res, next, endpointid) {
    if (!endpointid) {
      return next();
    }

    req.rateLimitEndpointId = endpointid;
    const limits = await this.getEndpointLimits(req.accountid, endpointid);
    req.rateLimitConfig = limits;

    if (!this.hasActiveLimits(limits)) {
      return next();
    }

    const [allowed] = await this.reserveRateLimit(
      req.accountid,
      endpointid,
      limits
    );

    if (!allowed) {
      return this.respondTooManyRequests(
        req,
        res,
        "RATE_LIMIT_EXCEEDED",
        "API rate limit exceeded"
      );
    }

    req._rateLimitReserved = {
      accountid: req.accountid,
      endpointid,
      limits,
    };
    return next();
  }

  withEndpoint(endpointid) {
    if (typeof endpointid !== "string" || !endpointid) {
      throw new Error("withEndpoint requires a non-empty endpointid string");
    }
    return async (req, res, next) => {
      try {
        if (!req.accountid) {
          return next();
        }
        return this.enforceEndpointRateLimit(req, res, next, endpointid);
      } catch (error) {
        this.logger.error("rate limit withEndpoint error", error);
        return next();
      }
    };
  }

  middleware() {
    return async (req, res, next) => {
      try {
        if (!req.accountid) {
          return next();
        }
        req.rateLimitSvc = this;
        this.wrapResponseForRateLimiting(req, res);
        return next();
      } catch (error) {
        this.logger.error("rate limit middleware error", error);
        return next();
      }
    };
  }
}
