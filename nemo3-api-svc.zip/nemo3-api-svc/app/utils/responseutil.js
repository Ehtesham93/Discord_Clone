export function apiresponseerror(errcode, errdata) {
    return { errcode, errdata };
  }

  export function apiresponseerrorcustom(errcode) {
    return errcode;
  }
  export function apiresponse(err, data, msg) {
    return { err, data, msg };
  }
  export function apiresponsecustom(data) {
    return { data };
  }
  export function APIResponseOK(req, res, data, msg) {
    res.status(200).send(apiresponse(null, data, msg));
  }
  export function APIResponseOKCustom(req, res, data) {
    res.status(200).send(apiresponsecustom(data));
  }
  
  export function APIResponseError(req, res, statuscode, errcode, errdata, msg) {
    return res.status(statuscode).send(apiresponse(apiresponseerror(errcode, null), null, msg));
  }
  export function APIResponseErrorCustom(req, res, errcode, error) {
    return res.status(errcode).send(apiresponseerrorcustom(error));
  }
  export function APIResponseBadRequest(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 400, errcode, errdata, msg);
  }
  
  export function APIResponseUnauthorized(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 401, errcode, errdata, msg);
  }
  
  export function APIResponseForbidden(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 403, errcode, errdata, msg);
  }

  export function APIResponseNotFoundCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 404, error);
  }

  export function APIResponseUnauthorizedCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 401, error);
  }

  export function APIResponseForbiddenCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 403, error);
  }

  export function APIResponseBadRequestCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 400, error);
  }

  export function APIResponseInternalErrCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 500, error);
  }

  export function APIResponseNotFound(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 404, errcode, errdata, msg);
  }
  export function APIResponseInternalErr(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 500, errcode, errdata, msg);
  }

  export function APIResponseTooManyRequests(req, res, errcode, errdata, msg) {
    return APIResponseError(req, res, 429, errcode, errdata, msg);
  }

  export function APIResponseTooManyRequestsCustom(req, res, error) {
    return APIResponseErrorCustom(req, res, 429, error);
  }