import z from "zod";
import {
  APIResponseOKCustom,
  APIResponseUnauthorizedCustom,
  APIResponseNotFoundCustom,
  APIResponseBadRequestCustom,
  APIResponseInternalErrCustom,
  APIResponseForbiddenCustom,
} from "../../utils/responseutil.js";
import promiserouter from "express-promise-router";
import { validateAllInputs } from "../../utils/validationutil.js";
import LegacyApiHdlrImpl from "./legacyhdlr_impl.js";
import PermLib from "../../../lib/nemo3-lib-permcheck/index.js"
import {AuthenticateAccessToken} from "../../utils/tokenutil.js"
import { getTokenFromRequest } from "../../utils/tokenutil.js";
import { recordAccountApiMetrics } from "../../utils/metricsutil.js";;
import { getMaxVinsPerCall } from "../../utils/ratelimiting.js";
import { GetSubscriptionAPIServicePermissions, hasEndpointPermission } from "../../utils/permissionutil.js";

export default class LegacyApiDiffHdlr {
  constructor(logger, config, apiserviceSvcI, rateLimitSvcI, clientmgmtSvcI) {
    this.logger = logger;
    this.impl = new LegacyApiHdlrImpl(logger, config, apiserviceSvcI);
    this.config = config;
    this.apiserviceSvcI = apiserviceSvcI;
    this.rateLimitSvcI = rateLimitSvcI;
    this.getSubscriptionAPIServicePermissions = GetSubscriptionAPIServicePermissions(clientmgmtSvcI, logger);
  }

  RegisterRoutes(router) {
    const accountTokenGroup = promiserouter();
    accountTokenGroup.use(AuthenticateAccessToken);
    accountTokenGroup.use(this.getSubscriptionAPIServicePermissions);
    accountTokenGroup.use(this.rateLimitSvcI.middleware());
    router.use("/", accountTokenGroup);
    accountTokenGroup.get(
      "/vehicles/livedetails",
      this.rateLimitSvcI.withEndpoint("getvehicleslivedetails"),
      this.GetLiveDetails
    );
    accountTokenGroup.get(
      "/vehicles/tripsummary",
      this.rateLimitSvcI.withEndpoint("getvehiclestripsummary"),
      this.GetTripSummary
    );
  }

  CheckUserPerms = async (userid, accountid, fleetid, requiredPermissions, mode, req) => {
    try{
      const permLib = new PermLib({
        userid: userid,
        accountid: accountid,
        fleetId: fleetid,
        requiredpermissions: requiredPermissions,
        mode: mode,
        req: req,
        logger: this.logger,
      });
    
      const result = await permLib.CheckWithWildCardModuleCode();
      return result;
    }catch(error) {
      this.logger.error(error);
      return false;
    }
  }

  GetLiveDetails = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getvehicleslivedetails", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getvehicleslivedetails")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  

      let schema = z.object({
        vins: z.preprocess(
          (val) => (Array.isArray(val) ? val : val != null && val !== "" ? [val] : val),
          z
          .array(z.string({ message: "Invalid VIN format" })
            .nonempty({ message: "Invalid VIN format" })
            .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
              message: "VIN must contain only letters, numbers, and spaces, and must not start or end with a space",
            })
            .max(128, { message: "Vin No must be at most 128 characters long" }))
          .min(1, { message: "At least one VIN is required" }),
      )});
      if (!getTokenFromRequest(req)){
        return APIResponseUnauthorizedCustom(req, res, {message: "Authentication required" });
      }
      const { vins } = validateAllInputs(schema, {
        vins: req.query.vins,
      });
      const maxVins = getMaxVinsPerCall(req);
      if (vins.length > maxVins) {
        return APIResponseBadRequestCustom(req, res, {
          errcode: "VIN_LIMIT_EXCEEDED",
          message: `Maximum ${maxVins} VINs allowed per request`,
        });
      }
      const liveDetails = await this.impl.GetLiveDetailsLogic(vins, req);
      if (liveDetails.errcode) {
        return APIResponseForbiddenCustom(req, res, {message: "Your subscription expired or not subscribed"});
      }
      return APIResponseOKCustom(req, res, liveDetails);
    }catch (error) {
      this.logger.error("Error getting live details:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, {message: "Something went wrong on our end. The technical team has been informed and will resolve the issue shortly."});
      
    }
  }
  GetTripSummary = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getvehiclestripsummary", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getvehiclestripsummary")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  

      let schema = z.object({
        vins: z.preprocess(
          (val) => (Array.isArray(val) ? val : val != null && val !== "" ? [val] : val),
          z
          .array(z.string({ message: "Invalid VIN format" })
            .nonempty({ message: "Invalid VIN format" })
            .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
              message: "VIN must contain only letters, numbers, and spaces, and must not start or end with a space",
            })
            .max(128, { message: "Vin No must be at most 128 characters long" }))
          .min(1, { message: "At least one VIN is required" }),
        ),
        selectDate: z.string({ message: "Invalid date format" })
          .nonempty({ message: "Invalid date format" })
          .regex(/^\d{4}-\d{2}-\d{2}$/, {
            message: "Date must be in YYYY-MM-DD format",
          }),
      });
      if (!getTokenFromRequest(req)){
        return APIResponseUnauthorizedCustom(req, res, {message: "Authentication required" });
      }
      const { vins, selectDate } = validateAllInputs(schema, {
        vins: req.query.vins,
        selectDate: req.query.selectDate,
      });
      const maxVins = getMaxVinsPerCall(req);
      if (vins.length > maxVins) {
        return APIResponseBadRequestCustom(req, res, {
          errcode: "VIN_LIMIT_EXCEEDED",
          message: `Maximum ${maxVins} VINs allowed per request`,
        });
      }
      const tripSummary = await this.impl.GetTripSummaryLogic(vins, selectDate, req);
      if (tripSummary.errcode) {
        return APIResponseForbiddenCustom(req, res, {message: "Your subscription expired or not subscribed"});
      }
      return APIResponseOKCustom(req, res, tripSummary);
    }catch (error) {
      this.logger.error("Error getting trip summary:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, {message: "Something went wrong on our end. The technical team has been informed and will resolve the issue shortly."});
      
    }
  }
}