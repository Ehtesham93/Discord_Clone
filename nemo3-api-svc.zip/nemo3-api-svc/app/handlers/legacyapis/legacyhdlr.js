import z from "zod";
import {
  APIResponseOKCustom,
  APIResponseUnauthorizedCustom,
  APIResponseNotFoundCustom,
  APIResponseBadRequestCustom,
  APIResponseInternalErrCustom,
  APIResponseForbiddenCustom,
} from "../../utils/responseutil.js";
import promiserouter from "express-promise-router";
import { validateAllInputs } from "../../utils/validationutil.js";
import { parseQueryInt } from "../../utils/commonutil.js";
import LegacyApiHdlrImpl from "./legacyhdlr_impl.js";
import PermLib from "../../../lib/nemo3-lib-permcheck/index.js"
import { AuthenticateAccessToken, getTokenFromRequest } from "../../utils/tokenutil.js";
import { getMaxVinsPerCall } from "../../utils/ratelimiting.js";;
import { recordAccountApiMetrics } from "../../utils/metricsutil.js";
import { GetSubscriptionAPIServicePermissions, hasEndpointPermission } from "../../utils/permissionutil.js";

export default class LegacyApiHdlr {
  constructor(logger, config, apiserviceSvcI, rateLimitSvcI, clientmgmtSvcI) {
    this.logger = logger;
    this.impl = new LegacyApiHdlrImpl(logger, config, apiserviceSvcI);
    this.config = config;
    this.apiserviceSvcI = apiserviceSvcI;
    this.rateLimitSvcI = rateLimitSvcI;
    this.getSubscriptionAPIServicePermissions = GetSubscriptionAPIServicePermissions(clientmgmtSvcI, logger);
  }

  RegisterRoutes(router) {
    router.put("/history/downloadstatus/:reportid/update", this.UpdateHistoryReportStatus);
    const accountTokenGroup = promiserouter();
    accountTokenGroup.use(AuthenticateAccessToken);
    accountTokenGroup.use(this.getSubscriptionAPIServicePermissions);
    accountTokenGroup.use(this.rateLimitSvcI.middleware());
    router.use("/", accountTokenGroup);
    accountTokenGroup.get(
      "/vehicles/list",
      this.rateLimitSvcI.withEndpoint("getvehicleslist"),
      this.GetVehiclesList
    );
    accountTokenGroup.get(
      "/financier/vehicles",
      this.rateLimitSvcI.withEndpoint("getfinanciervehicles"),
      this.GetFinancierVehicles
    );
    accountTokenGroup.get(
      "/vehicles/:vin",
      this.rateLimitSvcI.withEndpoint("getvehiclebyvin"),
      this.GetVehicleInfo
    );
    accountTokenGroup.post(
      "/financier/fireCommand",
      this.rateLimitSvcI.withEndpoint("postfinancierfirecommand"),
      this.FireImmobilizerCommand
    );
    accountTokenGroup.post(
      "/vehicles/history",
      this.rateLimitSvcI.withEndpoint("postvehiclehistory"),
      this.GetVehicleHistory
    );
    accountTokenGroup.get(
      "/vehicles/:reportid/download",
      this.rateLimitSvcI.withEndpoint("getvehiclehistorydownload"),
      this.DownloadVehicleHistory
    );
  }

  processVinQuery = (req) => {
    try {
      const schema = z.object({
        vinno: z
          .array(
            z.string({ message: "Invalid VIN format" })
              .nonempty({ message: "VIN cannot be empty" })
              .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
                message: "VIN must be a valid format",
              })
              .max(128, { message: "VIN must not exceed 128 characters" })
          )
          .min(1, { message: "At least one VIN is required" }),
      });

      const { vinno } = validateAllInputs(schema, {
        vinno: req.query.vinno,
      });

      if (vinno.length === 0) {
        throw {
          errcode: "EMPTY_VIN_LIST",
          message: "VIN list cannot be empty",
        };
      }

      const maxVins = getMaxVinsPerCall(req);
      if (vinno.length > maxVins) {
        throw {
          errcode: "VIN_LIMIT_EXCEEDED",
          message: `Maximum ${maxVins} VINs allowed per request`,
        };
      }

      return vinno;
    } catch (error) {
      this.logger.error("Error processing VIN query:", error);
    }
  }
  CheckUserPerms = async (userid, accountid, fleetid, requiredPermissions, mode, req) => {
    try{
      const permLib = new PermLib({
        userid: userid,
        accountid: accountid,
        fleetId: fleetid,
        requiredpermissions: requiredPermissions,
        mode: mode,
        req: req,
        logger: this.logger,
      });
    
      const result = await permLib.CheckWithWildCardModuleCode();
      return result;
    }catch(error) {
      this.logger.error(error);
      return false;
    }
  }

  UpdateHistoryReportStatus = async (req, res) => {
    try {
      const schema = z.object({
        reportid: z
          .string({ message: "Report ID is required" })
          .uuid({ message: "Report ID must be a valid UUID" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Account ID must be a valid UUID" }),
        status: z.enum(["completed", "processing", "pending"], { message: "Status is required" }),
        oldstatus: z.enum(["completed", "processing", "pending"], { message: "Old status is required" }),
      });
      let { reportid, accountid, status, oldstatus } = validateAllInputs(schema, {
        reportid: req.params.reportid,
        accountid: req.body.accountid,
        status: req.body.status,
        oldstatus: req.body.oldstatus,
      });
      const result = await this.impl.UpdateHistoryReportStatusLogic(reportid, accountid, status, oldstatus);
      if (result.error) {
        return APIResponseNotFoundCustom(req, res, result);
      }
      return APIResponseOKCustom(req, res, result);
    } catch (error) {
      this.logger.error("Error updating history report status:", error);
      return APIResponseInternalErrCustom(req, res, error);
    }
  }

  GetVehiclesList = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getvehicleslist", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getvehicleslist")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  
      
      let schema = z.object({
        search: z
          .string({ message: "Search text is required" })
          .optional()
          .nullable()
          .default("")
          .refine((val) => !val || val.length === 0 || val.length >= 3, {
            message: "Search text must be at least 3 characters long",
          }),
        offset: z
          .number({ message: "Offset must be a number" })
          .optional()
          .default(0),
        limit: z
          .number({ message: "Limit must be a number" })
          .optional()
          .default(1000),
      });
      if (!getTokenFromRequest(req)) {
        return APIResponseUnauthorizedCustom(req, res, { message: "Authentication required" });
      }
      let { search, offset, limit } = validateAllInputs(schema, {
        search: req.query.search,
        offset: parseQueryInt(req.query.offset),
        limit: parseQueryInt(req.query.limit),
      });
      const vehicleInfo = await this.impl.GetVehiclesListLogic(search, offset, limit, req);
      if (vehicleInfo.error) {
        return APIResponseNotFoundCustom(req, res, vehicleInfo);
      }
      return APIResponseOKCustom(req, res, vehicleInfo);
    } catch (error) {
      this.logger.error("Error getting vehicles list:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
        return APIResponseInternalErrCustom(req, res, error);
    }
  }

  GetVehicleInfo = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getvehiclebyvin", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getvehiclebyvin")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  

      let schema = z.object({
        vin: z
          .string({ message: "Invalid VIN format" })
          .nonempty({ message: "Invalid VIN format" })
          .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
            message:
              "VIN must contain only letters, numbers, and spaces, and must not start or end with a space",
          })
          .max(128, { message: "Vin No must be at most 128 characters long" }),
      });
      if (!getTokenFromRequest(req)) {
        return APIResponseUnauthorizedCustom(req, res, { message: "Authentication required" });
      }
      let { vin } = validateAllInputs(schema, {
        vin: req.params.vin,
      });
      const vehicleInfo = await this.impl.GetVehicleInfoLogic(vin, req);
      if (vehicleInfo.error) {
        return APIResponseNotFoundCustom(req, res, vehicleInfo);
      }
      return APIResponseOKCustom(req, res, vehicleInfo);
    } catch (error) {
      this.logger.error("Error getting vehicle info:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, error);
      
    }
  }

  GetFinancierVehicles = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getfinanciervehicles", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getfinanciervehicles")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  

      let schema = z.object({
        search: z
          .string({ message: "Search text is required" })
          .optional()
          .nullable()
          .default("")
          .refine((val) => !val || val.length === 0 || val.length >= 3, {
            message: "Search text must be at least 3 characters long",
          }),
        offset: z
          .number({ message: "Offset must be a number" })
          .optional()
          .default(0),
        limit: z
          .number({ message: "Limit must be a number" })
          .optional()
          .default(1000),
      });
      if (!getTokenFromRequest(req)) {
        return APIResponseUnauthorizedCustom(req, res, { message: "Authentication required" });
      }
      let { search, offset, limit } = validateAllInputs(schema, {
        search: req.query.search,
        offset: parseQueryInt(req.query.offset),
        limit: parseQueryInt(req.query.limit),
      });
      const vehicleInfo = await this.impl.GetFinancierVehiclesLogic(search, offset, limit, req);
      if (vehicleInfo.error) {
        return APIResponseNotFoundCustom(req, res, vehicleInfo);
      }
      return APIResponseOKCustom(req, res, vehicleInfo);
    } catch (error) {
      this.logger.error("Error getting financier vehicles:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, error);
    }
  }
  FireImmobilizerCommand = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "postfinancierfirecommand", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "postfinancierfirecommand")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  

      let schema = z.object({
        vin: z
          .string({ message: "Invalid VIN format" })
          .nonempty({ message: "Invalid VIN format" })
          .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
            message: "VIN must contain only letters, numbers, and spaces, and must not start or end with a space",
          })
          .max(128, { message: "Vin No must be at most 128 characters long" }),
        command: z.enum(["drive_disable", "drive_enable"], {
            message: "Invalid command format",
          }),
      });
      if (!getTokenFromRequest(req)) {
        return APIResponseUnauthorizedCustom(req, res, { message: "You are unauthorized to access the resource" });
      }
      const { vin, command } = validateAllInputs(schema, {
        vin: req.body.vin,
        command: req.body.command,
      });
      const immobilizerInfo = await this.impl.FireImmobilizerCommandLogic(vin, command, req);
      if (immobilizerInfo.errcode) {
        return APIResponseNotFoundCustom(req, res, {message: immobilizerInfo.message});
      }
      return APIResponseOKCustom(req, res, immobilizerInfo);
    }catch (error) {
      this.logger.error("Error firing immobilizer command:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }else if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequestCustom(req, res, error);
      }else if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequestCustom(req, res, error);
      }else if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }else{
        return APIResponseInternalErrCustom(req, res, {"message": "Oops! Something went wrong, Informed to tech team. "});
      }
    }
  }

  GetVehicleHistory = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "postvehiclehistory", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "postvehiclehistory")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }  
  
      const schema = z.object({
        vinList: z.preprocess(
          (val) => (Array.isArray(val) ? val : val != null && val !== "" ? [val] : val),
          z
          .array(
            z.string({ message: "Invalid VIN format" })
              .nonempty({ message: "VIN cannot be empty" })
              .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
                message: "VIN must be a valid format",
              })
              .max(128, { message: "VIN must not exceed 128 characters" })
          ))
          .min(1, { message: "At least one VIN is required" }),
        date: z.string({ message: "Invalid date format" })
          .nonempty({ message: "Invalid date format" })
          .regex(/^\d{2}-\d{2}-\d{4}$/, { message: "Date must be in MM-DD-YYYY format" }),
        reportType: z.enum(["regular", "gps"], { message: "Invalid reportType" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Account ID must be a valid UUID" }),
        clientid: z
          .string({ message: "Client ID is required" })
          .uuid({ message: "Client ID must be a valid UUID" }),
      });
  
      const { vinList, date, reportType, accountid, clientid } = validateAllInputs(schema, {
        vinList: req.body?.vinList,
        date: req.body?.date,
        reportType: req.body?.reportType,
        accountid: req.accountid,
        clientid: req.clientid,
      });
      const maxVins = getMaxVinsPerCall(req);
      if (vinList.length > maxVins) {
        return APIResponseBadRequestCustom(req, res, {
          errcode: "VIN_LIMIT_EXCEEDED",
          message: `Maximum ${maxVins} VINs allowed per request`,
        });
      }
      const result = await this.impl.GetVehicleHistoryLogic(vinList, date, reportType, accountid, clientid);
      if (result.error) {
        return APIResponseNotFoundCustom(req, res, result);
      }
      return APIResponseOKCustom(req, res, result);
    } catch (error) {
      this.logger.error("Error initiating vehicle history report:", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequestCustom(req, res, error);
      }else if (error?.errcode === "NO_DATA") {
        return APIResponseNotFoundCustom(req, res, { message: error.message });
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequestCustom(req, res, error);
      }
      if (error.errorcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, { message: "Something went wrong on our end. Please try again." });
    }
  };
  
  DownloadVehicleHistory = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getvehiclehistorydownload", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getvehiclehistorydownload")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
  
      const schema = z.object({
        reportid: z
        .string({ message: "Report ID is required" })
        .uuid({ message: "Report ID must be a valid UUID" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Account ID must be a valid UUID" }),
      });
  
      const { reportid, accountid } = validateAllInputs(schema, { 
        reportid: req.params.reportid, 
        accountid: req.accountid,
      });
  
      const result = await this.impl.DownloadVehicleHistoryLogic(reportid, accountid);

      if (result?.errcode === "NO_DATA_FOUND") {
        return res.status(404).json({ message: result.message });
      }

      res.setHeader("Content-Type", result.headers["Content-Type"]);
      res.setHeader("Content-Disposition", result.headers["Content-Disposition"]);
      return res.status(200).send(result.buffer);
    } catch (error) {
      this.logger.error("Error downloading vehicle history:", error);
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbiddenCustom(req, res, error);
      }
      return APIResponseInternalErrCustom(req, res, { message: "Something went wrong on our end. Please try again." });
      
    }
  };
}