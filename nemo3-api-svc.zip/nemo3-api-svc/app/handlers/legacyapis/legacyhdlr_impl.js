import { formatEpochToDateTime, ymdToStartEndEpochMsIST, mdyToStartEndEpochMsIST } from "../../utils/epochconverter.js";
import { v4 as uuidv4 } from "uuid";
export default class LegacyApiHdlrImpl {
    constructor(logger, config, apiserviceSvcI) {
      this.logger = logger;
      this.config = config;
      this.apiserviceSvcI = apiserviceSvcI;
    }
    async GetVehiclesListLogic(search, offset, limit, req) {
      try {
        const data = await this.apiserviceSvcI.GetVehicleInfo(search, offset, limit, req);
        if (data.vininfo.totalcount === 0) {
          return { error: "not found" , error_description: "No data found"};
        }
        let response = { count: data.vininfo.totalcount, rows: [] };
        for (const vindata of data.vininfo.vehicles) {
          const last_connected = data.vehiclestatus[vindata.vinno]?.last_connected ? formatEpochToDateTime(data.vehiclestatus[vindata.vinno]?.last_connected) : null;
          response.rows.push({
            vin: vindata.vinno,
            license_plate: vindata.license_plate,
            vehicle_model: vindata.modelname,
            vehicle_variant: vindata.modelvariant,
            color: vindata.color,
            ac: "OFF",
            battery_temp: data.batterystatus[vindata.vinno]?.temperature,
            gear_position: data.vehiclestatus[vindata.vinno]?.gear_position,
            soc: data.batterystatus[vindata.vinno]?.soc,
            kwh: data.batterystatus[vindata.vinno]?.kwh,
            distance_to_empty: data.batterystatus[vindata.vinno]?.dte,
            drive_state: data.vehiclestatus[vindata.vinno]?.vehicle_status,
            odometer: data.vehiclestatus[vindata.vinno]?.odometer,
            latitude: data.vehiclelocation[vindata.vinno]?.lat,
            longitude: data.vehiclelocation[vindata.vinno]?.long,
            last_connected: last_connected,
          });
        }
        return response;
      } catch (error) {
        throw error;
      }
    }

    async GetVehicleInfoLogic(vin, req) {
      try {
        const data = await this.apiserviceSvcI.GetVehicleInfo(vin, null, null, req);
        if (data.vininfo.totalcount === 0) {
          return { error: "not found" , error_description: "No data found"};
        }
        let response = { count: data.vininfo.totalcount, rows: [] };
        for (const vindata of data.vininfo.vehicles) {
          const last_connected = data.vehiclestatus[vindata.vinno]?.last_connected ? formatEpochToDateTime(data.vehiclestatus[vindata.vinno]?.last_connected) : null;
          response.rows.push({
            vin: vindata.vinno,
            license_plate: vindata.license_plate,
            vehicle_model: vindata.modelname,
            vehicle_variant: vindata.modelvariant,
            color: vindata.color,
            battery_temp: data.batterystatus[vindata.vinno]?.temperature,
            gear_position: data.vehiclestatus[vindata.vinno]?.gear_position,
            soc: data.batterystatus[vindata.vinno]?.soc,
            kwh: data.batterystatus[vindata.vinno]?.kwh,
            distance_to_empty: data.batterystatus[vindata.vinno]?.dte,
            state: data.vehiclestatus[vindata.vinno]?.vehicle_status,
            odometer: data.vehiclestatus[vindata.vinno]?.odometer,
            latitude: data.vehiclelocation[vindata.vinno]?.lat,
            longitude: data.vehiclelocation[vindata.vinno]?.long,
            valid: data.vehiclelocation[vindata.vinno]?.gps_validity_flag,
            last_connected: last_connected,
          });
        }
        return response;
      } catch (error) {
        throw error;
      }
    }

    async GetFinancierVehiclesLogic(search, offset, limit, req) {
      try {
        const data = await this.apiserviceSvcI.GetVehicleInfo(search, offset, limit, req);
        if (data.vininfo.totalcount === 0) {
          return { error: "not found" , error_description: "No data found"};
        }
        let response = { count: data.vininfo.totalcount, rows: [] };
        for (const vindata of data.vininfo.vehicles) {
          const last_connected = data.vehiclestatus[vindata.vinno]?.last_connected ? formatEpochToDateTime(data.vehiclestatus[vindata.vinno]?.last_connected) : null;
          response.rows.push({
            vin: vindata.vinno,
            vehicle_model: vindata.modelname,
            vehicle_variant: vindata.modelvariant,
            license_plate: vindata.license_plate,
            last_connected: last_connected,
            tgu: vindata.tgu_model || "",
            imei: vindata.tgu_imei_no || "",
            vehicle_state: data.vehiclestatus[vindata.vinno]?.vehicle_status,
            operation_mode: data.vehiclestatus[vindata.vinno]?.immo_status,
            immo_status: "awaiting",
          });
        }
        return response;
      } catch (error) {
        throw error;
      }
    }
    async FireImmobilizerCommandLogic(vin, command, req) {
      try {
        const data = await this.apiserviceSvcI.FireImmobilizerCommand(vin, command, req);
        if (data.errcode) {
          return { errcode: data.errcode, message: data.message };
        }
        return data;
      } catch (error) {
        throw error;
      }
    }
    async GetLiveDetailsLogic(vins, req) {
      try {
        const data = await this.apiserviceSvcI.GetLiveDetails(vins, req);
        if (data.errcode) {
          return { errcode: data.errcode};
        }
        return data;
      } catch (error) {
        throw error;
      }
    }
    async GetTripSummaryLogic(vins, selectDate, req) {
      try {
        const { startEpochMs, endEpochMs } = ymdToStartEndEpochMsIST(selectDate);
        const data = await this.apiserviceSvcI.GetTripSummary(vins, startEpochMs, endEpochMs, selectDate, req);
        if (data.errcode) {
          return { errcode: data.errcode};
        }
        return data;
      } catch (error) {
        throw error;
      }
    }
    //records3path = s3:lmm-intellicar/download-reports/2026/03/08/17ce0f61-168e-4c5e-ab53-63d387a5217c/regular/uuid.csv
    async GetVehicleHistoryLogic(vinList, date, reportType, accountid, clientid) {
      try {
        const recordid = uuidv4();
        const { startEpochMs, endEpochMs } = mdyToStartEndEpochMsIST(date);
        const [m, d, y] = date.split("-").map(Number);
        const records3path = this.config.reportDownload.records3pathprefix + y + "/" + m + "/" + d + "/" + accountid + "/" + reportType + "/" + recordid + ".csv";
        const response = await this.apiserviceSvcI.InitiateVehicleHistoryReport(accountid, recordid, vinList, startEpochMs, endEpochMs, clientid, reportType, records3path);
        return response;
      } catch (error) {
        throw error;
      }
    }
    async DownloadVehicleHistoryLogic(reportid, accountid) {
      try {
        const response = await this.apiserviceSvcI.GetHistoryDownloadStatus(reportid, accountid);
        return response;
      } catch (error) {
        this.logger.error("Error downloading report:", error);
        throw error;
      }
    }

    async UpdateHistoryReportStatusLogic(reportid, accountid, status, oldstatus) {
      try {
        const data = await this.apiserviceSvcI.UpdateHistoryReportStatus(reportid, accountid, status, oldstatus);
        return data;
      } catch (error) {
        throw error;
      }
    }
  }