import z from "zod";
import {
  APIResponseOK,
  APIResponseBadRequest,
  APIResponseForbidden,
  APIResponseInternalErr,
} from "../utils/responseutil.js";
import promiserouter from "express-promise-router";
import { validateAllInputs } from "../utils/validationutil.js";
import ApiHdlrImpl from "./apihdlr_impl.js";
import PermLib from "../../lib/nemo3-lib-permcheck/index.js";
import { AuthenticateAccessToken } from "../utils/tokenutil.js"
import { recordAccountApiMetrics } from "../utils/metricsutil.js";
import { getMaxVinsPerCall } from "../utils/ratelimiting.js";
import { GetSubscriptionAPIServicePermissions, hasEndpointPermission } from "../utils/permissionutil.js";

export default class ApiHdlr {
  constructor(logger, config, apiserviceSvcI, rateLimitSvcI, authSvcI, clientmgmtSvcI) {
    this.logger = logger;
    this.impl = new ApiHdlrImpl(logger, config, apiserviceSvcI, authSvcI);
    this.config = config;
    this.apiserviceSvcI = apiserviceSvcI;
    this.rateLimitSvcI = rateLimitSvcI;
    this.authSvcI = authSvcI;
    this.getSubscriptionAPIServicePermissions = GetSubscriptionAPIServicePermissions(clientmgmtSvcI, logger);
  }

  RegisterRoutes(router) {
    const accountTokenGroup = promiserouter();
    router.post("/refreshtoken", this.refreshClientToken);
    router.post("/token", this.generateClientToken);
    accountTokenGroup.use(AuthenticateAccessToken);
    accountTokenGroup.use(this.getSubscriptionAPIServicePermissions);
    accountTokenGroup.use(this.rateLimitSvcI.middleware());
    router.use("/", accountTokenGroup);
    accountTokenGroup.get(
      "/fleetvehicleinfo",
      this.rateLimitSvcI.withEndpoint("getfleetvehicleinfo"),
      this.GetFleetVehicleInfo
    );
    accountTokenGroup.get(
      "/fleetvehicleinfo/advanced",
      this.rateLimitSvcI.withEndpoint("getfleetvehicleinfoadvanced"),
      this.GetFleetVehicleInfoAdvanced
    );
    accountTokenGroup.get(
      "/financiervehicleinfo",
      this.rateLimitSvcI.withEndpoint("getfinanciervehicleinfo"),
      this.GetFinancierVehicleInfo
    );
    accountTokenGroup.get(
      "/financiervehicleinfo/advanced",
      this.rateLimitSvcI.withEndpoint("getfinanciervehicleinfoadvanced"),
      this.GetFinancierVehicleInfoAdvanced
    );

  }

  processVinQuery = (req) => {
    try {
      const schema = z.object({
        vinno: z
          .array(
            z.string({ message: "Invalid VIN format" })
              .nonempty({ message: "VIN cannot be empty" })
              .regex(/^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$/, {
                message: "VIN must be a valid format",
              })
              .max(128, { message: "VIN must not exceed 128 characters" })
          )
          .min(1, { message: "At least one VIN is required" }),
      });

      const rawVinno = req.query.vinno;
      const vinnoInput =
        rawVinno == null ? undefined : Array.isArray(rawVinno) ? rawVinno : [rawVinno];


      const { vinno } = validateAllInputs(schema, {
        vinno: vinnoInput,
      });

      if (vinno.length === 0) {
        throw {
          errcode: "EMPTY_VIN_LIST",
          message: "VIN list cannot be empty",
        };
      }

      const maxVins = getMaxVinsPerCall(req);
      if (vinno.length > maxVins) {
        throw {
          errcode: "VIN_LIMIT_EXCEEDED",
          message: `Maximum ${maxVins} VINs allowed per request`,
        };
      }

      return vinno;
    } catch (error) {
      this.logger.error("Error processing VIN query:", error);
    }
  }
  CheckUserPerms = async (userid, accountid, fleetid, requiredPermissions, mode, req) => {
    try{
      const permLib = new PermLib({
        userid: userid,
        accountid: accountid,
        fleetId: fleetid,
        requiredpermissions: requiredPermissions,
        mode: mode,
        req: req,
        logger: this.logger,
      });
    
      const result = await permLib.CheckWithWildCardModuleCode();
      return result;
    }catch(error) {
      this.logger.error(error);
      return false;
    }
  }

  GetFleetVehicleInfo = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getfleetvehicleinfo", req, res);

      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getfleetvehicleinfo")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
      

      const vinList = this.processVinQuery(req);
      const vehicleInfo = await this.impl.GetFleetVehicleInfoLogic(vinList, req);
      return APIResponseOK(req, res, vehicleInfo, "Successfully fetched fleet vehicle info");
    } catch (error) {
      this.logger.error("Error getting fleet vehicle info:", error);
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequest(req, res, error, "VIN list cannot be empty");
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequest(req, res, error, error.message || "VIN limit exceeded");
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbidden(req, res, error, "Permission denied");
      }
      return APIResponseInternalErr(req, res, error, "Error getting fleet vehicle info");
    }
  }
  GetFleetVehicleInfoAdvanced = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getfleetvehicleinfoadvanced", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getfleetvehicleinfoadvanced")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const vinList = this.processVinQuery(req);
      const vehicleInfo = await this.impl.GetFleetVehicleInfoAdvancedLogic(vinList, req);
      return APIResponseOK(req, res, vehicleInfo, "Successfully fetched fleet vehicle info advanced");
    } catch (error) {
      this.logger.error("Error getting fleet vehicle info advanced:", error);
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequest(req, res, error, "VIN list cannot be empty");
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequest(req, res, error, error.message || "VIN limit exceeded");
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbidden(req, res, error, "Permission denied");
      }
      return APIResponseInternalErr(req, res, error, "Error getting fleet vehicle info advanced");
    }
  }
  GetFinancierVehicleInfo = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getfinanciervehicleinfo", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getfinanciervehicleinfo")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const vinList = this.processVinQuery(req);
      const vehicleInfo = await this.impl.GetFinancierVehicleInfoLogic(vinList, req);
      return APIResponseOK(req, res, vehicleInfo, "Successfully fetched financier vehicle info");
    } catch (error) {
      this.logger.error("Error getting financier vehicle info:", error);
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequest(req, res, error, "VIN list cannot be empty");
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequest(req, res, error, error.message || "VIN limit exceeded");
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbidden(req, res, error, "Permission denied");
      }
      return APIResponseInternalErr(req, res, error, "Error getting financier vehicle info");
    }
  }
  GetFinancierVehicleInfoAdvanced = async (req, res) => {
    try {
      recordAccountApiMetrics(this.logger, "getfinanciervehicleinfoadvanced", req, res);
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !hasEndpointPermission(permissions, "getfinanciervehicleinfoadvanced")) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const vinList = this.processVinQuery(req);
      const vehicleInfo = await this.impl.GetFinancierVehicleInfoAdvancedLogic(vinList, req);
      return APIResponseOK(req, res, vehicleInfo, "Successfully fetched financier vehicle info advanced");
    } catch (error) {
      this.logger.error("Error getting financier vehicle info advanced:", error);
      if (error.errcode === "EMPTY_VIN_LIST") {
        return APIResponseBadRequest(req, res, error, "VIN list cannot be empty");
      }
      if (error.errcode === "VIN_LIMIT_EXCEEDED") {
        return APIResponseBadRequest(req, res, error, error.message || "VIN limit exceeded");
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      if (error.errcode === "PERMISSIONS_DENIED") {
        return APIResponseForbidden(req, res, error, "Permission denied");
      }
      return APIResponseInternalErr(req, res, error, "Error getting financier vehicle info advanced");
    }
  }

  generateClientToken = async (req, res) => {
    try {
      const schema = z.object({
        clientid: z
          .string({ message: "Client ID is required" })
          .length(16, { message: "Client ID must be exactly 16 characters" }),
        clientsecret: z
          .string({ message: "Client secret is required" })
          .length(32, {
            message: "Client secret must be exactly 32 characters",
          }),
      });
      const { clientid, clientsecret } = validateAllInputs(schema, {
        clientid: req.body.clientid,
        clientsecret: req.body.clientsecret,
      });
      const result = await this.impl.GenerateClientTokenLogic({ clientid, clientsecret });
      return APIResponseOK(req, res, result, "Client token fetched successfully");
    }
    catch (error) {
      this.logger.error("generateClientToken failed", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to generate client token",
      );
    }
  };

  refreshClientToken = async (req, res) => {
    try {
      let result = await this.impl.RefreshClientTokenLogic(
        req
      );
      if (!result) {
        return APIResponseBadRequest(
          req,
          res,
          "INVALID_REFRESH_TOKEN",
          {},
          "Invalid refresh token",
        );
      }
      return APIResponseOK(req, res, result, "Client token refreshed successfully");
    }
    catch (error) {
      this.logger.error("refreshClientToken failed", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(req, res, error, error.message);
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to refresh client token",
      );
    }
  };
}