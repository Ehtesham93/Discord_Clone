import z from "zod";
import {
  APIResponseOK,
  APIResponseBadRequest,
  APIResponseForbidden,
  APIResponseInternalErr,
} from "../../utils/responseutil.js";
import promiserouter from "express-promise-router";
import { validateAllInputs } from "../../utils/validationutil.js";
import ClientmgmtHdlrImpl from "./clientmgmthdlr_impl.js";
import { AuthenticateUserTokenFromCookie } from "../../utils/tokenutil.js";
import {
  CheckUserPerms,
  GetMyPerms,
} from "../../utils/permissionutil.js";

export default class ClientmgmtHdlr {
  constructor(
    logger,
    config,
    pgPoolI,
    clientmgmtSvcI,
    authSvcI,
    apiserviceSvcI,
    
  ) {
    this.logger = logger;
    this.impl = new ClientmgmtHdlrImpl(
      logger,
      config,
      pgPoolI,
      clientmgmtSvcI,
      authSvcI,
      apiserviceSvcI,
    );
    this.config = config;
    this.getMyPerms = GetMyPerms(clientmgmtSvcI, logger);
  }

  RegisterRoutes(router) {
    const accountTokenGroup = promiserouter();
    accountTokenGroup.use(AuthenticateUserTokenFromCookie);
    accountTokenGroup.use(this.getMyPerms);
    router.use("/", accountTokenGroup);
    accountTokenGroup.post(
      "/account/:accountid/clientmgmt/credentials",
      this.createApiClient,
    );
    accountTokenGroup.post(
      "/account/:accountid/clientmgmt/credentials/rotate",
      this.rotateApiSecret,
    );
    accountTokenGroup.get(
      "/account/:accountid/clientmgmt/overview",
      this.getClientOverview,
    );
    accountTokenGroup.get(
      "/account/:accountid/clientmgmt/endpoint/:endpointid/metrics",
      this.getEndpointMetrics,
    );

    accountTokenGroup.get(
      "/account/:accountid/endpoints",
      this.getAccountAPIEndpoints,
    );
    accountTokenGroup.put(
      "/account/:accountid/endpoint/:endpointid",
      this.updateAccountEndpoint,
    );
    accountTokenGroup.delete(
      "/account/:accountid/endpoint/:endpointid",
      this.deleteAccountEndpoint,
    );
    accountTokenGroup.get("/endpoints", this.getAPIEndpoints);
    accountTokenGroup.post("/endpoint", this.createApiEndpoint);
    accountTokenGroup.put("/endpoint/:endpointid", this.updateApiEndpoint);
    accountTokenGroup.delete("/endpoint/:endpointid", this.deleteApiEndpoint);

  }



  createApiClient = async (req, res) => {
    try {
      const schema = z.object({
        label: z
          .string({ message: "Client name is required" })
          .min(1)
          .max(128)
          .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/, {
            message: "Invalid client name format",
          }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        userid: z
          .string({ message: "User ID is required" })
          .uuid({ message: "Invalid user ID format" }),
      });

      const { label, accountid, userid } = validateAllInputs(schema, {
        label: req.body.label,
        accountid: req.params.accountid,
        userid: req.userid,
      });

      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to create API client",
        );
      }

      const result = await this.impl.CreateApiClientLogic({
        label,
        accountid,
        userid,
      });

      return APIResponseOK(req, res, result, "API client created");
    } catch (error) {
      this.logger.error("createApiClient failed", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          error.errdata,
          error.message,
        );
      }
      if (error.errcode === "API_CLIENT_EXISTS") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          {},
          error.message,
        );
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to create API client",
      );
    }
  };

  rotateApiSecret = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        clientid: z.string({ message: "Client ID is required" }),
        purgeold: z
          .boolean({ message: "Purge old secret is required" })
          .default(false),
      });

      const { accountid, clientid, purgeold } = validateAllInputs(schema, {
        accountid: req.params.accountid,
        clientid: req.body.clientid,
        purgeold: req.body.purgeold,
      });

      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to create API client",
        );
      }

      const result = await this.impl.RotateApiSecretLogic({
        accountid,
        clientid,
        purgeold,
      });

      return APIResponseOK(req, res, result, "API client secret rotated");
    } catch (error) {
      this.logger.error("rotateApiClient failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to rotate API client",
      );
    }
  };

  getAPIEndpoints = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.apiservice.view",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to view API Services",
        );
      }
      const result = await this.impl.GetAPIEndpointsLogic();
      return APIResponseOK(
        req,
        res,
        result,
        "API endpoints fetched successfully",
      );
    } catch (error) {
      this.logger.error("getAPIEndpoints failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get API endpoints",
      );
    }
  };

  getClientOverview = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.view",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to view account",
        );
      }
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
      });
      const { accountid } = validateAllInputs(schema, {
        accountid: req.params.accountid,
      });
      const result = await this.impl.GetClientEndpointDetailsLogic(accountid);
      return APIResponseOK(
        req,
        res,
        result,
        "Endpoint details fetched successfully",
      );
    } catch (error) {
      this.logger.error("getEndpointDetails failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get endpoint details",
      );
    }
  };

  getAccountAPIEndpoints = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.view",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to view account",
        );
      }
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
      });
      const { accountid } = validateAllInputs(schema, {
        accountid: req.params.accountid,
      });
      const result = await this.impl.GetAccountAPIEndpointsLogic(accountid);
      return APIResponseOK(
        req,
        res,
        result,
        "API endpoints fetched successfully",
      );
    } catch (error) {
      this.logger.error("getAccountAPIEndpoints failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get API endpoints",
      );
    }
  };

  getEndpointMetrics = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.view",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to view account",
        );
      }
      const schema = z.object({
        endpointid: z.string({ message: "Endpoint ID is required" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        fromTime: z.string().optional(),
        toTime: z.string().optional(),
      });
      const { endpointid, accountid, fromTime, toTime } = validateAllInputs(
        schema,
        {
          endpointid: req.params.endpointid,
          accountid: req.params.accountid,
          fromTime: req.query.fromTime,
          toTime: req.query.toTime,
        }
      );
      const result = await this.impl.GetEndpointMetricsLogic(
        accountid,
        endpointid,
        fromTime, toTime
      );
      return APIResponseOK(
        req,
        res,
        result,
        "Endpoint overview fetched successfully"
      );
    } catch (error) {
      this.logger.error("getEndpointMetrics failed", error);
      if (error.errcode === "ENDPOINT_NOT_FOUND") {
        return APIResponseBadRequest(req, res, error.errcode, {}, error.message);
      }
      if (
        error.errcode === "ENDPOINT_NOT_ASSIGNED" ||
        error.errcode === "ENDPOINT_ROUTE_NOT_FOUND"
      ) {
        return APIResponseBadRequest(req, res, error.errcode, {}, error.message);
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get endpoint overview",
      );
    }
  };

  updateAccountEndpoint = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to update account endpoint",
        );
      }
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        endpointid: z.string({ message: "Endpoint ID is required" }),
        userid: z.string({ message: "User ID is required" }).uuid({ message: "Invalid user ID format" }),
        ratepermin: z.number({ message: "Rate per minute is required" }).optional(),
        rateperhour: z.number({ message: "Rate per hour is required" }).optional(),
        rateperday: z.number({ message: "Rate per day is required" }).optional(),
        maxvinspercall: z.number({ message: "Max VINs per call is required" }).optional(),
        max_history_days: z.number({ message: "Max history days is required" }).optional(),
        ishistory: z.boolean({ message: "Is history is required" }).optional(),
      });
      const { accountid, endpointid, userid, ratepermin, rateperhour, rateperday, maxvinspercall, max_history_days, ishistory } = validateAllInputs(schema, {
        accountid: req.params.accountid,
        endpointid: req.params.endpointid,
        userid: req.userid,
        ratepermin: req.body.ratepermin,
        rateperhour: req.body.rateperhour,
        rateperday: req.body.rateperday,
        maxvinspercall: req.body.maxvinspercall,
        max_history_days: req.body.max_history_days,
        ishistory: req.body.ishistory,
      });
      const result = await this.impl.UpdateAccountEndpointLogic(accountid, endpointid, { ratepermin, rateperhour, rateperday, maxvinspercall, max_history_days, ishistory }, userid);
      return APIResponseOK(
        req,
        res,
        result,
        "Account endpoint updated successfully",
      );
    } catch (error) {
      this.logger.error("updateAccountEndpoint failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to update account endpoint",
      );
    }
  };

  deleteAccountEndpoint = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.account.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to delete account endpoint",
        );
      }
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        endpointid: z.string({ message: "Endpoint ID is required" }),
      });
      const { accountid, endpointid } = validateAllInputs(schema, {
        accountid: req.params.accountid,
        endpointid: req.params.endpointid,
      });
      const result = await this.impl.DeleteAccountEndpointLogic({
        accountid,
        endpointid,
      });
      return APIResponseOK(
        req,
        res,
        result,
        "Account endpoint deleted successfully",
      );
    } catch (error) {
      this.logger.error("deleteAccountEndpoint failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to delete account endpoint",
      );
    }
  };

  createApiEndpoint = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.apiservice.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to create API endpoint",
        );
      }
      const schema = z.object({
        endpointname: z.string({ message: "Endpoint name is required" }),
        endpointid: z.string({ message: "Endpoint ID is required" }),
        ratepermin: z.number({ message: "Rate per minute is required" }),
        rateperhour: z
          .number({ message: "Rate per hour is required" })
          .optional(),
        rateperday: z.number({ message: "Rate per day is required" }),
        maxvinspercall: z.number().optional(),
        max_history_days: z.number().optional(),
        ishistory: z.boolean({ message: "Is history is required" }),
        userid: z
          .string({ message: "User ID is required" })
          .uuid({ message: "Invalid user ID format" }),
      });
      const {
        endpointname,
        endpointid,
        ratepermin,
        rateperhour,
        rateperday,
        maxvinspercall,
        max_history_days,
        ishistory,
        userid,
      } = validateAllInputs(schema, {
        endpointname: req.body.endpointname,
        endpointid: req.body.endpointid,
        ratepermin: req.body.ratepermin,
        rateperhour: req.body.rateperhour,
        rateperday: req.body.rateperday,
        maxvinspercall: req.body.maxvinspercall,
        max_history_days: req.body.max_history_days,
        ishistory: req.body.ishistory,
        userid: req.userid,
      });
      const result = await this.impl.CreateApiEndpointLogic({
        endpointname,
        endpointid,
        ratepermin,
        rateperhour,
        rateperday,
        maxvinspercall,
        max_history_days,
        ishistory,
        userid,
      });
      return APIResponseOK(
        req,
        res,
        result,
        "API endpoint created successfully",
      );
    } catch (error) {
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          error.errdata,
          error.message,
        );
      }
      if (error.errcode === "ENDPOINT_EXISTS") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          {},
          error.message,
        );
      }
      this.logger.error("createApiEndpoint failed", error);
      return APIResponseInternalErr(
        req,
        res,
        "INTERNAL_SERVER_ERROR",
        error.message,
        "Failed to create API endpoint",
      );
    }
  };

  updateApiEndpoint = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.apiservice.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to update account endpoint",
        );
      }
      const schema = z.object({
        endpointid: z.string({ message: "Endpoint ID is required" }),
        ratepermin: z.number({ message: "Rate per minute is required" }),
        rateperday: z.number({ message: "Rate per day is required" }),
        maxvinspercall: z.number({ message: "Max VINs per call is required" }),
        max_history_days: z
          .number({ message: "Max history days is required" })
          .optional(),
        ishistory: z.boolean({ message: "Is history is required" }),
        userid: z
          .string({ message: "User ID is required" })
          .uuid({ message: "Invalid user ID format" }),
      });
      const {
        endpointid,
        ratepermin,
        rateperday,
        maxvinspercall,
        max_history_days,
        ishistory,
        userid,
      } = validateAllInputs(schema, {
        endpointid: req.params.endpointid,
        ratepermin: req.body.ratepermin,
        rateperday: req.body.rateperday,
        maxvinspercall: req.body.maxvinspercall,
        max_history_days: req.body.max_history_days,
        ishistory: req.body.ishistory,
        userid: req.userid,
      });
      const result = await this.impl.UpdateApiEndpointLogic({
        endpointid,
        ratepermin,
        rateperday,
        maxvinspercall,
        max_history_days,
        ishistory,
        userid,
      });
      return APIResponseOK(
        req,
        res,
        result,
        "API endpoint updated successfully",
      );
    } catch (error) {
      this.logger.error("updateApiEndpoint failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to update API endpoint",
      );
    }
  };

  deleteApiEndpoint = async (req, res) => {
    try {
      const allowed = CheckUserPerms(req.userperms, [
        "consolemgmt.apiservice.admin",
      ]);
      if (!allowed) {
        return APIResponseForbidden(
          req,
          res,
          "INSUFFICIENT_PERMISSIONS",
          null,
          "Not allowed to update account endpoint",
        );
      }
      const schema = z.object({
        endpointid: z.string({ message: "Endpoint ID is required" }),
      });
      const { endpointid } = validateAllInputs(schema, {
        endpointid: req.params.endpointid,
      });
      const result = await this.impl.DeleteApiEndpointLogic(endpointid);
      return APIResponseOK(
        req,
        res,
        result,
        "API endpoint deleted successfully",
      );
    } catch (error) {
      this.logger.error("deleteApiEndpoint failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to delete API endpoint",
      );
    }
  };
}
