import {
  buildClientId,
  generateHashedClientSecret,
  hashClientSecretForStorage,
} from "../../utils/eccutil.js"; //should it be done from new utils file?

export default class ClientmgmtHdlrImpl {
  constructor(
    logger,
    config,
    pgPoolI,
    clientmgmtSvcI,
    authSvcI,
    apiserviceSvcI,
    
  ) {
    this.logger = logger;
    this.config = config;
    this.pgPoolI = pgPoolI;
    this.clientmgmtSvc = clientmgmtSvcI;
    this.authSvcI = authSvcI;
    this.apiserviceSvcI = apiserviceSvcI;
  }

  async RotateApiSecretLogic({ accountid, clientid, purgeold }) {
    try {
      const existing =
        await this.clientmgmtSvc.getApiClientByAccountId(accountid);
      if (!existing) {
        throw {
          errcode: "API_CLIENT_NOT_FOUND",
          message: "API client not found for this account",
        };
      }

      if (clientid !== existing.clientid) {
        throw {
          errcode: "CLIENT_ID_MISMATCH",
          message: "Client ID does not match this account",
        };
      }

      const plaintext = `${clientid}-${accountid}-${existing.label}`;
      const plainClientSecret = generateHashedClientSecret(plaintext);
      const clientsecret = await hashClientSecretForStorage(plainClientSecret);
      let clientsecretold = existing.clientsecret;
      if (purgeold) {
        clientsecretold = clientsecret;
      }
      const result = await this.clientmgmtSvc.RotateApiSecret({
        accountid,
        clientid,
        clientsecret,
        clientsecretold,
      });
      if (!result) {
        throw new Error("Failed to rotate API client secret");
      }

      return {
        clientid: result.clientid,
        clientsecret: plainClientSecret,
      };
    } catch (error) {
      throw error;
    }
  }

  async CreateApiClientLogic( clientdata ) {
    let [txclient, txnerr] = await this.pgPoolI.StartTransaction();
    if (txnerr) {
      throw txnerr;
    }
    try {
      const accountid = clientdata.accountid;
      const label = clientdata.label;
      const userid = clientdata.userid;
      const existing =
        await this.clientmgmtSvc.getApiClientByAccountId(clientdata.accountid);
      if (existing) {
        throw {
          errcode: "API_CLIENT_EXISTS",
          message: "API client already exists for this account",
        };
      }

      const clientid = buildClientId(label, accountid);
      const plaintext = `${clientid}-${accountid}-${label}`;
      const plainClientSecret = generateHashedClientSecret(plaintext);
      const clientsecret = await hashClientSecretForStorage(plainClientSecret);

      const result = await this.clientmgmtSvc.CreateApiClient(
        {
          accountid,
          clientid,
          clientsecret,
          label,
          userid,
        },
        txclient,
      );
      if (!result) {
        throw new Error("Failed to create API client");
      }

      const res = await this.authSvcI.CreateConsumer(clientid);

      if (res === undefined || res === null || !res) {
        throw new Error("Failed to create consumer in authsvc");
      }

      let commiterr = await this.pgPoolI.TxCommit(txclient);
      if (commiterr) {
        throw commiterr;
      }

      return {
        clientid: result.clientid,
        clientsecret: plainClientSecret,
        label: result.label,
        accountid: result.accountid,
        createdat: result.createdat,
        createdby: result.createdby,
      };
    } catch (error) {
      let rollbackerr = await this.pgPoolI.TxRollback(txclient);
      if (rollbackerr) {
        this.logger.error("CreateApiClientLogic rollback failed", rollbackerr);
      }
      throw error;
    }
  }

  async DeleteApiClientLogic({ clientid, accountid }) {
    let [txclient, txnerr] = await this.pgPoolI.StartTransaction();
    if (txnerr) {
      throw txnerr;
    }
    try {
      const existing =
        await this.clientmgmtSvc.getApiClientByAccountId(accountid);
      if (!existing) {
        throw {
          errcode: "API_CLIENT_NOT_FOUND",
          message: "API client not found for this account",
        };
      }
      if (existing.clientid !== clientid) {
        throw {
          errcode: "CLIENT_ID_MISMATCH",
          message: "Client ID does not match this account",
        };
      }
      const result = await this.clientmgmtSvc.DeleteApiClient(
        { clientid },
        txclient,
      );
      if (!result) {
        throw new Error("Failed to delete API client");
      }

      const authres = await this.authSvcI.DeleteConsumer(clientid);
      if (authres === undefined || authres === null || !authres) {
        throw new Error("Failed to delete consumer in authsvc");
      }

      let commiterr = await this.pgPoolI.TxCommit(txclient);
      if (commiterr) {
        throw commiterr;
      }
      return {
        clientid: result.clientid,
      };
    } catch (error) {
      let rollbackerr = await this.pgPoolI.TxRollback(txclient);
      if (rollbackerr) {
        this.logger.error("DeleteApiClientLogic rollback failed", rollbackerr);
      }
      throw error;
    }
  }

  async GetAccountAPIEndpointsLogic(accountid) {
    try {
      const existing =
        await this.clientmgmtSvc.getApiClientByAccountId(accountid);
      if (!existing) {
        // throw {
        //   errcode: "API_CLIENT_NOT_FOUND",
        //   message: "API client not found for this account",
        // };
        return null;
      }
      let endpoints = await this.clientmgmtSvc.getAccountAPIEndpoints(accountid);
      if (!endpoints) {
        throw {
          errcode: "API_ENDPOINTS_NOT_FOUND",
          message: "API endpoints not found for this account",
        };
      }
      return {
        endpoints: endpoints,
      };
    }
    catch (error) {
      throw error;
    }
  };

  async GetAPIEndpointsLogic() {
    try {
      const endpoints = await this.clientmgmtSvc.getAPIEndpoints();
      if (!endpoints) {
        throw {
          errcode: "API_ENDPOINTS_NOT_FOUND",
          message: "API endpoints not found",
        };
      }
      return {
        endpoints: endpoints,
      };
    }
    catch (error) {
      throw error;
    }
  };

  async GetClientEndpointDetailsLogic(accountid) {
    try {
      const demoCredentials = await this.apiserviceSvcI.GetDemoAccountCredentials(accountid);
      let existing = null;
      if (!demoCredentials) {
        existing = await this.clientmgmtSvc.getApiClientByAccountId(accountid);
        if (!existing) {
          return null;
        }
      }
      let endpoints = await this.clientmgmtSvc.getAccountAPIEndpoints(accountid);
      if (!endpoints) {
        throw {
          errcode: "API_ENDPOINTS_NOT_FOUND",
          message: "API endpoints not found for this account",
        };
      }
      for (const endpoint of endpoints) {
        if (endpoint.max_history_days===0) {
          endpoint.max_history_days = "N/A";
        }
      } 
      if(demoCredentials) {
        return {
          accountid: demoCredentials.accountid,
          clientid: demoCredentials.clientid,
          isdemo: true,
          label: demoCredentials.label,
          secret: demoCredentials.clientsecret,
          createdat: demoCredentials.createdat,
          createdby: demoCredentials.createdby,
          updatedat: demoCredentials.createdat,
          updatedby: demoCredentials.createdby,
          endpoints: endpoints,
        };
      }
      return {
        accountid: existing.accountid,
        clientid: existing.clientid,
        isdemo: false,
        label: existing.label,
        createdat: existing.createdat,
        createdby: existing.createdby,
        updatedat: existing.updatedat,
        updatedby: existing.updatedby,
        endpoints: endpoints,
      };
    }
    catch (error) {
      throw error;
    }
  };

  async GetEndpointMetricsLogic(accountid, endpointid, fromTime, toTime) {
    try {
      const endpoint = await this.clientmgmtSvc.getEndpointDetails(endpointid);
      if (!endpoint) {
        throw {
          errcode: "ENDPOINT_NOT_FOUND",
          message: "Endpoint not found",
        };
      }

      const maxrateLimit = endpoint.defaultratepermin * 10;
      const metrics = await this.clientmgmtSvc.getRequestMetrics({
        accountid: accountid,
        endpointid,
        fromTime: fromTime || "now-24h",
        toTime: toTime || "now",
        maxRateLimit: maxrateLimit,
      });

      return {
        metrics: metrics,
      };
    } catch (error) {
      throw error;
    }
  }

  async UpdateAccountEndpointLogic(accountid, endpointid, body, userid) {
    try {
      const client = await this.clientmgmtSvc.getApiClientByAccountId(accountid);
      if (!client) {
        throw {
          errcode: "API_CLIENT_NOT_FOUND",
          message: "API client not found for this account",
        };
      }
      const existing =
        await this.clientmgmtSvc.getAccountAPIEndpoints(accountid);
      if (!existing) {
        throw {
          errcode: "ENDPOINT_NOT_FOUND",
          message: "Endpoint not found",
        };
      }

      if (existing.find(endpoint => endpoint.endpointid === endpointid)) {

        if (!body.ratepermin || body.ratepermin === undefined) {
          body.ratepermin = existing.defaultratepermin;
        }
  
        if (!body.rateperhour || body.rateperhour === undefined) {
          body.rateperhour = existing.defaultratehour;
        }
  
        if (!body.rateperday || body.rateperday === undefined) {
          body.rateperday = existing.defaultrateperday;
        }
  
        if (!body.maxvinspercall || body.maxvinspercall === undefined) {
          body.maxvinspercall = existing.maxvinspercall;
        }
  
        if (!body.max_history_days || body.max_history_days === undefined) {
          body.max_history_days = 30;
        }
  
        if (!body.ishistory || body.ishistory === undefined) {
          body.ishistory = existing.ishistory;
        }
        const result = await this.clientmgmtSvc.updateAccountEndpoint(accountid, endpointid, body, userid);
        return result;
      }
      throw {
        errcode: "ENDPOINT_NOT_FOUND",
        message: "Endpoint not found",
      };
    }
    catch (error) {
      throw error;
    }
  };

  async DeleteAccountEndpointLogic({ accountid, endpointid }) {
    try {
      const client = await this.clientmgmtSvc.getApiClientByAccountId(accountid);
      if (!client) {
        throw {
          errcode: "API_CLIENT_NOT_FOUND",
          message: "API client not found for this account",
        };
      }
      const existing =
        await this.clientmgmtSvc.getAccountAPIEndpoints(accountid);
      if (!existing) {
        throw {
          errcode: "ENDPOINT_NOT_FOUND",
          message: "Endpoint not found",
        };
      }
      if (existing.find(endpoint => endpoint.endpointid === endpointid)) {  
        const result = await this.clientmgmtSvc.deleteAccountEndpoint(accountid, endpointid);
        return result;
      } else {
        throw {
          errcode: "ENDPOINT_NOT_FOUND",
          message: "Endpoint not found",
        };
      }
    }
    catch (error) {
      throw error;
    }
  };

  async CreateApiEndpointLogic(endpointData) {
    try {
      const currenttime = new Date();
      const endpoint = await this.clientmgmtSvc.getEndpointDetails(endpointData.endpointid);
      if (endpoint) {
        throw {
          errcode: "ENDPOINT_EXISTS",
          message: "Endpoint already exists",
        };
      }
      const result = await this.clientmgmtSvc.createApiEndpoint(endpointData);
      return result;
    }
    catch (error) {
      throw error;
    }
  };

  async UpdateApiEndpointLogic(updateData) {
    try {
      const result = await this.clientmgmtSvc.updateApiEndpoint(updateData);
      return result;
    }
    catch (error) {
      throw error;
    }
  };

  async DeleteApiEndpointLogic(endpointid) {
    try {
      const existing =
        await this.clientmgmtSvc.getEndpointDetails(endpointid);
      if (!existing) {
        throw {
          errcode: "ENDPOINT_NOT_FOUND",
          message: "Endpoint not found",
        };
      }
      const result = await this.clientmgmtSvc.deleteApiEndpoint(endpointid);
      return {
        endpointid: result.endpointid,
        message: "API endpoint deleted successfully",
      };
    }
    catch (error) {
      throw error;
    }
  };

  async CreateDemoApiClientLogic(label, accountid, userid) {
    try {

      const clientid = buildClientId(label, accountid);
      const plaintext = `${clientid}-${accountid}-${label}`;
      const plainClientSecret = generateHashedClientSecret(plaintext);
    

      const result = await this.clientmgmtSvc.createDemoApiClient({accountid, clientid, plainClientSecret, label, userid});

      return {
        clientid: result.clientid,
        clientsecret: result.clientsecret,
        label: result.label,
      };
    }
    catch (error) {
      throw error;
    }
  };

  async RotateDemoApiSecretLogic(accountid, clientid) {
    try {
      const currenttime = new Date();
      const result = await this.clientmgmtSvc.rotateDemoApiSecret(accountid, clientid);
      if (!result) {
        throw {
          errcode: "DEMO_API_SECRET_NOT_FOUND",
          message: "Demo API secret not found",
        };
      }
      return {
        clientid: result.clientid,
        clientsecret: result.clientsecret,
        label: result.label,
        accountid: result.accountid,
        createdat: result.createdat,
        createdby: result.createdby,
      };
    }
    catch (error) {
      throw error;
    }
  };

  async GetDemoApiClientOverviewLogic(accountid) {
    try {
      const result = await this.clientmgmtSvc.getDemoApiClientByAccountId(accountid);
      if (!result) {
        throw {
          errcode: "DEMO_API_CLIENT_NOT_FOUND",
          message: "Demo API client not found",
        };
      }
      const endpoints = await this.clientmgmtSvc.getDemoAccountAPIEndpoints(accountid);
      if (!endpoints) {
        throw {
          errcode: "ENDPOINTS_NOT_FOUND",
          message: "Endpoints not found",
        };
      }
      return {
        clientid: result.clientid,
        clientsecret: result.clientsecret,
        label: result.label,
        endpoints: endpoints,
      };
    }
    catch (error) {
      throw error;
    }
  };
}
