import z from "zod";
import {
  APIResponseOK,
  APIResponseBadRequest,
  APIResponseForbidden,
  APIResponseInternalErr,
} from "../../utils/responseutil.js";
import promiserouter from "express-promise-router";
import { validateAllInputs } from "../../utils/validationutil.js";
import ClientmgmtHdlrImpl from "./clientmgmthdlr_impl.js";
import PermLib from "../../../lib/nemo3-lib-permcheck/index.js";
import { AuthenticateAccountTokenFromCookie } from "../../utils/tokenutil.js";
import { GetMyAPIServicePermissions } from "../../utils/permissionutil.js";

export default class ClientmgmtFmsHdlr {
  constructor(
    logger,
    config,
    pgPoolI,
    clientmgmtSvcI,
    authSvcI,
    apiserviceSvcI,
    
  ) {
    this.logger = logger;
    this.impl = new ClientmgmtHdlrImpl(
      logger,
      config,
      pgPoolI,
      clientmgmtSvcI,
      authSvcI,
      apiserviceSvcI,
      
    );
    this.config = config;
    this.clientmgmtSvcI = clientmgmtSvcI;
    this.getMyAPIServicePermissions = GetMyAPIServicePermissions(clientmgmtSvcI, logger);
  }

  RegisterRoutes(router) {
    const accountTokenGroup = promiserouter();
    accountTokenGroup.use(AuthenticateAccountTokenFromCookie);
    accountTokenGroup.use(this.getMyAPIServicePermissions);  
    
    router.use("/", accountTokenGroup);
    accountTokenGroup.post("/credentials", this.createApiClient);
    accountTokenGroup.post("/credentials/rotate", this.rotateApiSecret);
    accountTokenGroup.delete("/", this.deleteApiClient);
    // accountTokenGroup.post("/auth", this.authenticateApiClient);
    accountTokenGroup.get("/overview", this.getClientEndpointDetails);
    accountTokenGroup.get("/endpoint/:endpointid/metrics", this.getEndpointMetrics);
    accountTokenGroup.get("/demo/overview", this.getDemoApiClientOverview);
    // accountTokenGroup.get("/:accountid", this.getAccountAPIEndpoints);

    accountTokenGroup.post("/demo/credentials", this.createDemoApiClient);
    accountTokenGroup.post("/demo/credentials/rotate", this.rotateDemoApiSecret);
    
    // accountTokenGroup.delete("/demo", this.deleteDemoApiClient);
  }

  rotateApiSecret = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        clientid: z.string({ message: "Client ID is required" }),
        purgeold: z
          .boolean({ message: "Purge old secret is required" })
          .default(false),
      });

      const { accountid, clientid, purgeold } = validateAllInputs(schema, {
        accountid: req.accountid,
        clientid: req.body.clientid,
        purgeold: req.body.purgeold,
      });

      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !permissions.includes('apiservice.apimanagement.admin')) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const result = await this.impl.RotateApiSecretLogic({
        accountid,
        clientid,
        purgeold,
      });

      return APIResponseOK(req, res, result, "API client secret rotated");
    } catch (error) {
      this.logger.error("rotateApiClient failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to rotate API client",
      );
    }
  };

  createApiClient = async (req, res) => {
    try {
      const schema = z.object({
        label: z
          .string({ message: "Client name is required" })
          .min(1)
          .max(128)
          .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/, {
            message: "Invalid client name format",
          }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        userid: z
          .string({ message: "User ID is required" })
          .uuid({ message: "Invalid user ID format" }),
      });

      const { label, accountid, userid } = validateAllInputs(schema, {
        label: req.body.label,
        accountid: req.accountid,
        userid: req.userid,
      });

      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !permissions.includes('apiservice.apimanagement.admin')) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const result = await this.impl.CreateApiClientLogic({
        label,
        accountid,
        userid,
      });

      return APIResponseOK(req, res, result, "API client created");
    } catch (error) {
      this.logger.error("createApiClient failed", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          error.errdata,
          error.message,
        );
      }
      if (error.errcode === "API_CLIENT_EXISTS") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          {},
          error.message,
        );
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to create API client",
      );
    }
  };

  deleteApiClient = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        clientid: z.string({ message: "Client ID is required" }),
      });

      const { accountid, clientid } = validateAllInputs(schema, {
        accountid: req.accountid,
        clientid: req.body.clientid,
      });
      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !permissions.includes('apiservice.apimanagement.admin')) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const result = await this.impl.DeleteApiClientLogic({
        clientid,
        accountid,
      });

      return APIResponseOK(req, res, result, "API client deleted");
    } catch (error) {
      this.logger.error("deleteApiClient failed", error);
      if (error.errcode === "INPUT_ERROR") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          error.errdata,
          error.message,
        );
      }
      if (error.errcode === "API_CLIENT_NOT_FOUND") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          {},
          error.message,
        );
      }
      if (error.errcode === "CLIENT_ID_MISMATCH") {
        return APIResponseBadRequest(
          req,
          res,
          error.errcode,
          {},
          error.message,
        );
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to delete API client",
      );
    }
  };

  
  getAccountAPIEndpoints = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        
      });
      const { accountid } = validateAllInputs(schema, {
        accountid: req.accountid,
      });

      const permissions = req.permissions.perms;
      if (permissions.length === 0 && !req.permissions.admin) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const result = await this.impl.GetAccountAPIEndpointsLogic(accountid);
      return APIResponseOK(req, res, result, "API endpoints fetched successfully");
    }
    catch (error) {
      this.logger.error("getAccountAPIEndpoints failed", error);
      return APIResponseInternalErr(
        req,
        res,
        "INTERNAL_SERVER_ERROR",
        "Failed to get API endpoints",
      );
    }
  };


  getClientEndpointDetails = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
      });
      const { accountid } = validateAllInputs(schema, {
        accountid: req.accountid,
      });

      const permissions = req.permissions.perms;
      if (permissions.length === 0 && !req.permissions.admin) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }

      const result = await this.impl.GetClientEndpointDetailsLogic(accountid);
      return APIResponseOK(req, res, result, "Endpoint details fetched successfully");
    }
    catch (error) {
      this.logger.error("getEndpointDetails failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get endpoint details",
      );
    }
  };

  getEndpointMetrics = async (req, res) => {
    try {
      const schema = z.object({
        endpointid: z.string({ message: "Endpoint ID is required" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        starttime: z.string().optional(),
        endtime: z.string().optional(),
      });
      const { endpointid, accountid, starttime, endtime } = validateAllInputs(
        schema,
        {
          endpointid: req.params.endpointid,
          accountid: req.accountid,
          starttime: req.query.starttime,
          endtime: req.query.endtime,
        }
      );
      const permissions = req.permissions.perms;
      if (permissions.length === 0 && !req.permissions.admin) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
      const result = await this.impl.GetEndpointMetricsLogic(
        accountid,
        endpointid,
        starttime,
        endtime,
      );
      return APIResponseOK(
        req,
        res,
        result,
        "Endpoint overview fetched successfully"
      );
    } catch (error) {
      this.logger.error("getEndpointMetrics failed", error);
      if (error.errcode === "ENDPOINT_NOT_FOUND") {
        return APIResponseBadRequest(req, res, error.errcode, {}, error.message);
      }
      if (
        error.errcode === "ENDPOINT_NOT_ASSIGNED" ||
        error.errcode === "ENDPOINT_ROUTE_NOT_FOUND"
      ) {
        return APIResponseBadRequest(req, res, error.errcode, {}, error.message);
      }
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get endpoint overview",
      );
    }
  };

  createDemoApiClient = async (req, res) => {
    try {
      const schema = z.object({
        label: z
          .string({ message: "Client name is required" })
          .min(1)
          .max(128)
          .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/, {
            message: "Invalid client name format",
          }),
        userid: z
          .string({ message: "User ID is required" })
          .uuid({ message: "Invalid user ID format" }),
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
      });
      const { accountid, label, userid } = validateAllInputs(schema, {
        accountid: req.accountid,
        userid: req.userid,
        label: req.body.label,
      });

      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !permissions.includes('apiservice.apimanagement.admin')) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
      const result = await this.impl.CreateDemoApiClientLogic(label, accountid, userid);
      return APIResponseOK(req, res, result, "Demo API client created");
    } catch (error) {
      this.logger.error("createDemoApiClient failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to create demo API client",
      );
    }
  };


  rotateDemoApiSecret = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
        clientid: z
          .string({ message: "Client ID is required" }),
      });
      const { accountid, clientid } = validateAllInputs(schema, {
        accountid: req.accountid,
        clientid: req.body.clientid,
      });

      const permissions = req.permissions.perms;
      if (!req.permissions.admin && !permissions.includes('apiservice.apimanagement.admin')) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
      const result = await this.impl.RotateDemoApiSecretLogic(accountid, clientid);
      return APIResponseOK(req, res, result, "Demo API secret rotated");
    }
    catch (error) {
      this.logger.error("rotateDemoApiSecret failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to rotate demo API secret",
      );
    }
  };

  getDemoApiClientOverview = async (req, res) => {
    try {
      const schema = z.object({
        accountid: z
          .string({ message: "Account ID is required" })
          .uuid({ message: "Invalid account ID format" }),
      });

      const { accountid } = validateAllInputs(schema, {
        accountid: req.accountid,
      });
      const permissions = req.permissions.perms;
      if (permissions.length === 0 && !req.permissions.admin) {
        throw {
            errcode: 'PERMISSIONS_DENIED'
        }
    }
      const result = await this.impl.GetDemoApiClientOverviewLogic(accountid);
      return APIResponseOK(req, res, result, "Demo API client overview fetched successfully");
    }
    catch (error) {
      this.logger.error("getDemoApiClientOverview failed", error);
      return APIResponseInternalErr(
        req,
        res,
        error,
        "Failed to get demo API client overview",
      );
    }
  };
}
