import { verifyClientSecret } from "../../app/utils/eccutil.js";
import { GetUnVerifiedClaims } from "../../app/utils/jwtutil.js";
import { getTokenFromRequest } from "../../app/utils/tokenutil.js";
export default class ApiHdlrImpl {
    constructor(logger, config, apiserviceSvcI, authSvcI) {
      this.logger = logger;
      this.config = config;
      this.apiserviceSvcI = apiserviceSvcI;
      this.authSvcI = authSvcI;
    }
    async GetFleetVehicleInfoLogic(vinList, req) {
      try {
        const response = await this.apiserviceSvcI.GetFleetVehicleInfo(vinList, req);
        return response;
      } catch (error) {
        this.logger.error("Error getting fleet vehicle info:", error);
        throw new Error("Error getting fleet vehicle info");
      }
    }
    async GetFleetVehicleInfoAdvancedLogic(vinList, req) {
      try {
        const response = await this.apiserviceSvcI.GetFleetVehicleInfoAdvanced(vinList, req);
        return response;
      } catch (error) {
        this.logger.error("Error getting fleet vehicle info advanced:", error);
        throw new Error("Error getting fleet vehicle info advanced");
      }
    }
    async GetFinancierVehicleInfoLogic(vinList, req) {
      try {
        const response = await this.apiserviceSvcI.GetFinancierVehicleInfo(vinList, req);
        return response;
      } catch (error) {
        this.logger.error("Error getting financier vehicle info:", error);
        throw new Error("Error getting financier vehicle info");
      }
    }
    async GetFinancierVehicleInfoAdvancedLogic(vinList, req) {
      try {
        const response = await this.apiserviceSvcI.GetFinancierVehicleInfoAdvanced(vinList, req);
        return response;
      } catch (error) {
        this.logger.error("Error getting financier vehicle info advanced:", error);
        throw new Error("Error getting financier vehicle info advanced");
      }
    }

    async AuthenticateApiClientLogic({ clientid, clientsecret }) {
      try {
        //check is democlient and change the whole logic accordingly.
        if (!clientid) {
          const error = new Error("Client ID is required");
          error.errcode = "CLIENT_ID_REQUIRED";
          throw error;
        }
        if (!clientsecret) {
          const error = new Error("Client secret is required");
          error.errcode = "CLIENT_SECRET_REQUIRED";
          throw error;
        }

        const accountid =
          await this.apiserviceSvcI.GetAccountidUsingClientId(clientid);

        let demoCredentials = null;
        try {
          demoCredentials =
            await this.apiserviceSvcI.GetDemoAccountCredentials(accountid);
        } catch (error) {
          if (error.errcode !== "CREDENTIALS_NOT_FOUND") {
            throw error;
          }
        }

        if (demoCredentials) {
          if (demoCredentials.clientsecret !== clientsecret) {
            throw {
              errcode: "INVALID_CLIENT_SECRET",
              message: "Invalid client secret",
            };
          }

          return {
            clientid: demoCredentials.clientid,
            clientsecret: demoCredentials.clientsecret,
            accountid: demoCredentials.accountid,
          };
        }

        const currentTime = new Date();
        const existing =
          await this.apiserviceSvcI.GetClientSecretByClientId(clientid);
        if (!existing) {
          throw {
            errcode: "INVALID_CLIENT_ID",
            message: "Invalid client ID",
          };
        }
        let purgedImmediately = false;
        if (existing.clientsecret === existing.clientsecretold) {
          purgedImmediately = true;
        }
  
        let isAuthenticated = null;
        if (purgedImmediately) {
          isAuthenticated = await verifyClientSecret(
            clientsecret,
            existing.clientsecret,
          );
        } else {
          if (currentTime < existing.rotatedat + 24 * 60 * 60) {
            isAuthenticated = await verifyClientSecret(
              clientsecret,
              existing.clientsecretold,
            );
          }
          isAuthenticated = await verifyClientSecret(
            clientsecret,
            existing.clientsecret,
          );
        }
        if (!isAuthenticated) {
          throw {
            errcode: "INVALID_CLIENT_SECRET",
            message: "Invalid client secret",
          };
        }
  
        return {
          clientid: existing.clientid,
          clientsecret: existing.clientsecret,
          accountid: existing.accountid,
        };
      } catch (error) {
        throw error;
      }
    }


    async GenerateClientTokenLogic({ clientid, clientsecret }) {
      try {
        const authres = await this.AuthenticateApiClientLogic({
          clientid,
          clientsecret,
        });
        if (!authres) {
          throw {
            errcode: "INVALID_CLIENT_SECRET",
            message: "Invalid client secret",
          };
        }
  
  
        let tokenclaims = {
          claims: {
            accountid: authres.accountid,
            clientid: authres.clientid,
          },
          validity: this.config.apiToken.tokenexpirytime,
        };
        let refreshtokenclaims = {
          claims: {
            accountid: authres.accountid,
            clientid: authres.clientid,
          },
          validity: this.config.apiToken.refreshtokenexpirytime,
        };
  
        let res = await this.authSvcI.GetTokenAndRefreshToken(
          authres.clientid,
          tokenclaims,
          refreshtokenclaims
        );
        if (!res) {
          const error = new Error("Failed to get token and refresh token");
          error.errcode = "FAILED_TO_GET_TOKEN_AND_REFRESH_TOKEN";
          throw error;
        }
  
        return {
          access_token: res.token,
          refresh_token: res.refreshtoken,
          expires_in: this.config.apiToken.tokenexpirytime,
          token_type: "Bearer",
        };
      } catch (error) {
        throw error;
      }
    }
  
    async RefreshClientTokenLogic(req) {
      try{
        let maintoken = getTokenFromRequest(req);
        let refreshtoken = req.body.refreshtoken;
        if (!maintoken) {
          let error = new Error("Access token is required");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        if (!refreshtoken) {
          let error = new Error("Refresh token is required");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        let mainClaims = await GetUnVerifiedClaims(maintoken);
        if (!mainClaims) {
          let error = new Error("Invalid main token");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        let refreshClaims = await GetUnVerifiedClaims(refreshtoken);
        if (!refreshClaims) {
          let error = new Error("Invalid refresh token");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        if (!mainClaims.clientid) {
          let error = new Error("Client ID is missing in main token");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        if (!refreshClaims.clientid) {
          let error = new Error("Client ID is missing in refresh token");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        if (mainClaims.clientid !== refreshClaims.clientid) {
          let error = new Error(
            "Token clientid and refresh token clientid do not match"
          );
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        let client = await this.apiserviceSvcI.GetClientSecretByClientId(mainClaims.clientid);
        if (!client) {
          let error = new Error("Client not found");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
        if (client.accountid !== mainClaims.accountid) {
          let error = new Error("Client does not belong to the same account");
          error.errcode = "INVALID_TOKEN";
          throw error;
        }
  
        let validity = this.config.apiToken.tokenexpirytime;
  
  
        let tokenclaims = {
          claims: {
            clientid: mainClaims.clientid,
            accountid: mainClaims.accountid,
          },
          validity: validity,
        };
  
  
        let newtoken = await this.authSvcI.GetToken(mainClaims.clientid, tokenclaims);
  
        if (!newtoken) {
          throw new Error("Failed to refresh token");
        }
  
        return {
          clientid: mainClaims.clientid,
          access_token: newtoken.token,
          refresh_token: newtoken.refreshtoken,
        };
      }catch (error){
        throw error;
      }
    };
  }