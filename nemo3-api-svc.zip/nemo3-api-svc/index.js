import config from "./app/config/config.js";
import PgPool from "./app/utils/pgpool.js";
import RedisSvc from "./app/utils/redissvc.js";
import APIServer from "./app/apiservice.js";
import ApiServiceSvc from "./app/services/apiservicesvc.js";
import { Logger } from "./lib/nemo3-lib-observability/index.js";
import ApiHdlr from "./app/handlers/apihdlr.js";
import LegacyApiHdlr from "./app/handlers/legacyapis/legacyhdlr.js";
import LegacyApiDiffHdlr from "./app/handlers/legacyapis/legacyapidiffhdlr.js";
import ClientmgmtSvc from "./app/services/clientmgmt/clientmgmtsvc.js";
import ClientmgmtFmsHdlr from "./app/handlers/clientmgmt/clientmgmtfmshdlr.js";
import ClientmgmtHdlr from "./app/handlers/clientmgmt/clientmgmthdlr.js";
import AuthSvc from "./app/services/external/authsvc/authsvc.js";
import RateLimitSvc from "./app/utils/ratelimiting.js";
import ApiDocsSvc from "./app/services/apidocssvc.js";
import { swaggerDocs } from "./docs/swagger.js";

const logger = new Logger({
  environment: process.env.APP_ENV || "LOCAL",
  service: process.env.SERVICE_NAME || "nemo3-api-svc",
  instance: process.env.TASK_ARN || "localhost",
  ip: process.env.TASK_IP || "127.0.0.1",
  loglevel: "info",
  logToConsole: config.logToConsole || false,
  maxSizeBytes: 10 * 1024 * 1024,
  maxBackups: 5,
  checkIntervalMs: 2000,
  autoInstrument: true,
  flushInterval: 5000,
});

const apiserverport = config.apiserver.port;
const servicelogger = logger;
let pgPoolI = new PgPool(config.pgdb, servicelogger);

const redisSvcI = new RedisSvc(config.redis, servicelogger);
const [, redisConnectErr] = await redisSvcI.connect();
if (redisConnectErr) {
  servicelogger.error("Redis connection failed at startup", redisConnectErr);
}

const rateLimitSvcI = new RateLimitSvc(redisSvcI, pgPoolI, servicelogger, config);

const authSvcI = new AuthSvc(config, servicelogger);
const apiserviceSvcI = new ApiServiceSvc(pgPoolI, servicelogger, config);
const clientmgmtSvcI = new ClientmgmtSvc(pgPoolI, servicelogger);
const apiasservicehdlrI = new ApiHdlr(
  servicelogger,
  config,
  apiserviceSvcI,
  rateLimitSvcI,
  authSvcI,
  clientmgmtSvcI,
);
const legacyapishdlrI = new LegacyApiHdlr(
  servicelogger,
  config,
  apiserviceSvcI,
  rateLimitSvcI,
  clientmgmtSvcI,
);
const legacyapidiffhdlrI = new LegacyApiDiffHdlr(
  servicelogger,
  config,
  apiserviceSvcI,
  rateLimitSvcI,
  clientmgmtSvcI,
);
const clientmgmtHdlrI = new ClientmgmtHdlr(
  servicelogger,
  config,
  pgPoolI,
  clientmgmtSvcI,
  authSvcI,
  apiserviceSvcI,
);
const clientmgmtFmsHdlrI = new ClientmgmtFmsHdlr(
  servicelogger,
  config,
  pgPoolI,
  clientmgmtSvcI,
  authSvcI,
  apiserviceSvcI,
);


const apiRoutes = [
  ["/api/v1/apis", apiasservicehdlrI],
  ["/financial/api", legacyapishdlrI],
  ["/api/v1/fms/clientmgmt", clientmgmtFmsHdlrI],
  ["/api/v1/platform", clientmgmtHdlrI],
  ["/api", legacyapidiffhdlrI]
];


const App = new APIServer(apiRoutes, servicelogger);
const apiDocsSvcI = new ApiDocsSvc(pgPoolI, servicelogger);
swaggerDocs(App.app, config, apiDocsSvcI, apiserviceSvcI);
if (!config.logToConsole) {
  App.app.use(logger.getMetrics().middleware());
  logger.start();
}
App.Start(apiserverport);

const gracefulShutdown = async () => {
  try {
    await redisSvcI.disconnect();
    if (!config.logToConsole) {
      logger.stop();
      logger.flush();
    }
    process.exit(0);
  } catch (error) {
    console.log("Error during graceful shutdown:", error);
    process.exit(1);
  }
};

process.on("SIGINT", gracefulShutdown);
process.on("SIGTERM", gracefulShutdown);
