import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ENDPOINTS = JSON.parse(
  readFileSync(join(__dirname, "../../scripts/endpoint.json"), "utf8")
);

/** Always merged into account-scoped docs (not from account_rate_limits) */
export const ALWAYS_INCLUDED_ENDPOINT_IDS = [
  "postgeneratetoken",
  "postrefreshtoken",
];

const bearerSecurity = [{ bearerAuth: [] }];

function vinQueryParams() {
  return [
    {
      name: "vinno",
      in: "query",
      required: true,
      description: "One or more VIN numbers",
      schema: { $ref: "#/components/schemas/VinQuery" },
      style: "form",
      explode: true,
    },
  ];
}

function okResponse(description) {
  return {
    "200": {
      description,
      content: {
        "application/json": {
          schema: { $ref: "#/components/schemas/ApiResponse" },
        },
      },
    },
    "400": { $ref: "#/components/responses/BadRequest" },
    "403": { $ref: "#/components/responses/Forbidden" },
    "429": { $ref: "#/components/responses/TooManyRequests" },
    "500": { $ref: "#/components/responses/InternalError" },
  };
}

function httpMethodFromEndpointId(endpointid) {
  if (endpointid.startsWith("post")) return "post";
  if (endpointid.startsWith("put")) return "put";
  if (endpointid.startsWith("delete")) return "delete";
  return "get";
}

function toOpenApiPath(routePath) {
  return routePath.replace(/:(\w+)/g, "{$1}");
}

function tagForEndpoint(entry) {
  if (ALWAYS_INCLUDED_ENDPOINT_IDS.includes(entry.endpointid)) {
    return "Authentication";
  }
  const path = entry.routePath;
  if (path.startsWith("/api/v1/apis")) return "Vehicle Info";
  if (path.startsWith("/api/vehicles")) return "Legacy Vehicles";
  if (path.startsWith("/financial/api")) return "Legacy Financier";
  return "Legacy Financier";
}

const OPERATION_DETAILS = {
  postgeneratetoken: {
    security: [],
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            required: ["clientid", "clientsecret"],
            properties: {
              clientid: {
                type: "string",
                minLength: 16,
                maxLength: 16,
                description: "16-character API client ID",
              },
              clientsecret: {
                type: "string",
                minLength: 32,
                maxLength: 32,
                description: "32-character API client secret",
              },
            },
          },
        },
      },
    },
    responses: {
      "200": {
        description: "Access and refresh tokens",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                err: { nullable: true },
                data: {
                  type: "object",
                  properties: {
                    access_token: { type: "string" },
                    refresh_token: { type: "string" },
                    expires_in: { type: "integer" },
                    token_type: { type: "string", example: "Bearer" },
                  },
                },
                msg: { type: "string" },
              },
            },
          },
        },
      },
      "400": { $ref: "#/components/responses/BadRequest" },
      "500": { $ref: "#/components/responses/InternalError" },
    },
  },
  postrefreshtoken: {
    security: [{ bearerAuth: [] }],
    description:
      "Refresh an API client access token. Send the current access token as `Authorization: Bearer <token>` (or `Cookie: token=<access_token>`). Body carries the refresh token.",
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            required: ["refreshtoken"],
            properties: {
              refreshtoken: { type: "string" },
            },
          },
        },
      },
    },
    responses: {
      "200": {
        description: "New access and refresh tokens",
        content: {
          "application/json": {
            schema: { $ref: "#/components/schemas/ApiResponse" },
          },
        },
      },
      "400": { $ref: "#/components/responses/BadRequest" },
      "500": { $ref: "#/components/responses/InternalError" },
    },
  },
  getfleetvehicleinfo: {
    parameters: vinQueryParams(),
    responses: okResponse("Fleet vehicle info with valid and invalid VINs"),
  },
  getfleetvehicleinfoadvanced: {
    parameters: vinQueryParams(),
    responses: okResponse("Advanced fleet vehicle info"),
  },
  getfinanciervehicleinfo: {
    parameters: vinQueryParams(),
    responses: okResponse("Financier vehicle info"),
  },
  getfinanciervehicleinfoadvanced: {
    parameters: vinQueryParams(),
    responses: okResponse("Advanced financier vehicle info"),
  },
  puthistorydownloadstatusupdate: {
    security: [],
    parameters: [
      {
        name: "reportid",
        in: "path",
        required: true,
        schema: { type: "string", format: "uuid" },
      },
    ],
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            required: ["accountid", "status", "oldstatus"],
            properties: {
              accountid: { type: "string", format: "uuid" },
              status: {
                type: "string",
                enum: ["completed", "processing", "pending"],
              },
              oldstatus: {
                type: "string",
                enum: ["completed", "processing", "pending"],
              },
            },
          },
        },
      },
    },
    responses: okResponse("History report status updated"),
  },
  getvehicleslist: {
    parameters: [
      {
        name: "search",
        in: "query",
        schema: { type: "string" },
        description: "Min 3 characters when provided",
      },
      { name: "offset", in: "query", schema: { type: "integer", default: 0 } },
      { name: "limit", in: "query", schema: { type: "integer", default: 1000 } },
    ],
    responses: okResponse("Paginated vehicles list"),
  },
  getfinanciervehicles: {
    parameters: [
      { name: "search", in: "query", schema: { type: "string" } },
      { name: "offset", in: "query", schema: { type: "integer", default: 0 } },
      { name: "limit", in: "query", schema: { type: "integer", default: 1000 } },
    ],
    responses: okResponse("Financier vehicles list"),
  },
  getvehiclebyvin: {
    parameters: [
      {
        name: "vin",
        in: "path",
        required: true,
        schema: {
          type: "string",
          maxLength: 128,
          pattern: "^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$",
        },
      },
    ],
    responses: okResponse("Vehicle info by VIN"),
  },
  postfinancierfirecommand: {
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            required: ["vin", "command"],
            properties: {
              vin: { type: "string", maxLength: 128 },
              command: {
                type: "string",
                enum: ["drive_disable", "drive_enable"],
              },
            },
          },
        },
      },
    },
    responses: okResponse("Immobilizer command result"),
  },
  postvehiclehistory: {
    requestBody: {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: "object",
            required: ["vinList", "date", "reportType"],
            properties: {
              vinList: {
                type: "array",
                items: { type: "string" },
                minItems: 1,
              },
              date: {
                type: "string",
                pattern: "^\\d{2}-\\d{2}-\\d{4}$",
                description: "MM-DD-YYYY",
              },
              reportType: { type: "string", enum: ["regular", "gps"] },
            },
          },
        },
      },
    },
    responses: okResponse("Vehicle history report initiated"),
  },
  getvehiclehistorydownload: {
    parameters: [
      {
        name: "reportid",
        in: "path",
        required: true,
        schema: { type: "string", format: "uuid" },
      },
    ],
    responses: {
      "200": {
        description: "Report file download",
        content: {
          "application/octet-stream": {
            schema: { type: "string", format: "binary" },
          },
        },
      },
      "404": { description: "Report not found" },
      "429": { $ref: "#/components/responses/TooManyRequests" },
      "500": { $ref: "#/components/responses/InternalError" },
    },
  },
  getvehicleslivedetails: {
    parameters: [
      {
        name: "vins",
        in: "query",
        required: true,
        schema: { type: "array", items: { type: "string" }, minItems: 1 },
        style: "form",
        explode: true,
      },
    ],
    responses: okResponse("Live vehicle details"),
  },
  getvehiclestripsummary: {
    parameters: [
      {
        name: "vins",
        in: "query",
        required: true,
        schema: { type: "array", items: { type: "string" }, minItems: 1 },
        style: "form",
        explode: true,
      },
      {
        name: "selectDate",
        in: "query",
        required: true,
        schema: {
          type: "string",
          pattern: "^\\d{4}-\\d{2}-\\d{2}$",
          description: "YYYY-MM-DD",
        },
      },
    ],
    responses: okResponse("Trip summary"),
  },
};

function buildOperation(entry) {
  const details = OPERATION_DETAILS[entry.endpointid] ?? {};
  const method = httpMethodFromEndpointId(entry.endpointid);
  const operation = {
    tags: [tagForEndpoint(entry)],
    summary: entry.endpointname,
    operationId: entry.endpointid,
    security: details.security ?? bearerSecurity,
    responses: details.responses ?? okResponse(entry.endpointname),
  };
  if (details.description) operation.description = details.description;
  if (details.parameters) operation.parameters = details.parameters;
  if (details.requestBody) operation.requestBody = details.requestBody;
  return { [method]: operation };
}

function buildEndpointSpec(entry) {
  const openApiPath = toOpenApiPath(entry.routePath);
  return {
    paths: {
      [openApiPath]: buildOperation(entry),
    },
  };
}

export const ENDPOINT_SPECS = Object.fromEntries(
  ENDPOINTS.map((entry) => [entry.endpointid, buildEndpointSpec(entry)])
);

export function getEndpointName(endpointid) {
  return ENDPOINTS.find((e) => e.endpointid === endpointid)?.endpointname ?? endpointid;
}

export function resolveEndpointSpec(endpointid) {
  return ENDPOINT_SPECS[endpointid] ?? null;
}

export function getEndpointCatalog() {
  return ENDPOINTS;
}
