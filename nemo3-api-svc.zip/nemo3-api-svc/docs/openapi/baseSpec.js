export function createBaseSpec(config) {
  const baseUrl =
    config.reportDownload?.baseUrl ||
    `http://localhost:${config.apiserver?.port || 10004}`;

  return {
    openapi: "3.0.3",
    info: {
      title: "NEMO3 API Service",
      version: "1.0.0",
      description:
        "Account-scoped API documentation. When trying API operations below, authorize with `Authorization: Bearer <api_client_access_token>` from POST /api/v1/apis/token.",
    },
    servers: [{ url: baseUrl }],
    tags: [
      {
        name: "Authentication",
        description: "Generate and refresh API client tokens",
      },
      { name: "Vehicle Info", description: "Fleet and financier vehicle data APIs" },
      { name: "Legacy Financier", description: "Financial API legacy endpoints" },
      {
        name: "Legacy Vehicles",
        description: "Legacy vehicle live details and trip summary",
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
          description:
            "API client access token from POST /api/v1/apis/token. Send as: Authorization: Bearer <token>",
        },
      },
      schemas: {
        ApiResponse: {
          type: "object",
          properties: {
            err: { type: "object", nullable: true },
            data: {},
            msg: { type: "string" },
          },
        },
        VinQuery: {
          type: "array",
          items: {
            type: "string",
            maxLength: 128,
            pattern: "^[A-Za-z0-9](?:[A-Za-z0-9 ]*[A-Za-z0-9])?$",
          },
          minItems: 1,
        },
        ErrorResponse: {
          type: "object",
          properties: {
            err: {
              type: "object",
              properties: {
                errcode: { type: "string" },
                errdata: { nullable: true },
              },
            },
            data: { nullable: true },
            msg: { type: "string" },
          },
        },
      },
      responses: {
        BadRequest: {
          description: "Invalid request",
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/ErrorResponse" },
            },
          },
        },
        Forbidden: {
          description: "Insufficient permissions",
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/ErrorResponse" },
            },
          },
        },
        TooManyRequests: {
          description: "Rate limit exceeded",
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/ErrorResponse" },
            },
          },
        },
        InternalError: {
          description: "Internal server error",
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/ErrorResponse" },
            },
          },
        },
      },
    },
    paths: {},
  };
}
