import { createBaseSpec } from "./baseSpec.js";
import {
  ALWAYS_INCLUDED_ENDPOINT_IDS,
  getEndpointName,
  resolveEndpointSpec,
} from "./endpointRegistry.js";

const GENERATE_TOKEN_PATH = "/api/v1/apis/token";

function deepMergePaths(target, source) {
  for (const [path, methods] of Object.entries(source)) {
    if (!target[path]) {
      target[path] = { ...methods };
      continue;
    }
    target[path] = { ...target[path], ...methods };
  }
}

function applyAccountLimits(operation, accountRow) {
  if (!operation || !accountRow) return operation;
  const cloned = JSON.parse(JSON.stringify(operation));
  const limits = [];
  if (accountRow.ratepermin > 0) limits.push(`${accountRow.ratepermin}/min`);
  if (accountRow.rateperhour > 0) limits.push(`${accountRow.rateperhour}/hour`);
  if (accountRow.rateperday > 0) limits.push(`${accountRow.rateperday}/day`);
  if (accountRow.maxvinspercall > 0) {
    limits.push(`max ${accountRow.maxvinspercall} VINs per call`);
  }
  if (accountRow.max_history_days > 0) {
    limits.push(`max history ${accountRow.max_history_days} days`);
  }
  if (limits.length === 0) return cloned;

  const limitNote = `\n\n**Account limits:** ${limits.join(", ")}`;
  cloned.description = (cloned.description || "") + limitNote;
  return cloned;
}

function mergeEndpointIntoSpec(spec, endpointid, accountRow) {
  const endpointSpec = resolveEndpointSpec(endpointid);
  if (!endpointSpec?.paths) return false;

  const pathsToMerge = {};
  for (const [path, methods] of Object.entries(endpointSpec.paths)) {
    pathsToMerge[path] = {};
    for (const [method, operation] of Object.entries(methods)) {
      pathsToMerge[path][method] = applyAccountLimits(operation, accountRow);
    }
  }
  deepMergePaths(spec.paths, pathsToMerge);
  return true;
}

function applyDemoCredentials(spec, demoCredentials) {
  if (!demoCredentials?.clientid || !demoCredentials?.clientsecret) return;

  const operation = spec.paths[GENERATE_TOKEN_PATH]?.post;
  const content =
    operation?.requestBody?.content?.["application/json"];
  if (!content) return;

  const example = {
    clientid: demoCredentials.clientid,
    clientsecret: demoCredentials.clientsecret,
  };
  content.example = example;
  if (content.schema) {
    content.schema.example = example;
  }
}

/**
 * @param {object} config - app config
 * @param {Array} accountEndpoints - rows from account_rate_limits joined with api_endpoint
 * @param {object|null} [demoCredentials] - demo_account_client row when account is demo
 */
export function buildDynamicSpec(config, accountEndpoints, demoCredentials = null) {
  const spec = createBaseSpec(config);
  const included = [];
  const unknown = [];

  for (const endpointid of ALWAYS_INCLUDED_ENDPOINT_IDS) {
    const merged = mergeEndpointIntoSpec(spec, endpointid, null);
    if (merged) {
      included.push({
        endpointid,
        endpointname: getEndpointName(endpointid),
      });
    }
  }

  for (const row of accountEndpoints) {
    const endpointid = row.endpointid;
    if (ALWAYS_INCLUDED_ENDPOINT_IDS.includes(endpointid)) continue;

    const merged = mergeEndpointIntoSpec(spec, endpointid, row);
    if (merged) {
      included.push({
        endpointid,
        endpointname: row.endpointname ?? endpointid,
      });
    } else {
      unknown.push(endpointid);
    }
  }

  applyDemoCredentials(spec, demoCredentials);

  return { spec, included, unknown, isDemo: Boolean(demoCredentials) };
}
