import swaggerUi from "swagger-ui-express";
import yaml from "js-yaml";
import promiserouter from "express-promise-router";
import { buildDynamicSpec } from "./openapi/buildDynamicSpec.js";
import { apiReference } from "@scalar/express-api-reference";
import { AuthenticateAccountToken } from "../app/utils/tokenutil.js";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DEV_PORTAL_BASE = "/api/v1/apis/dev-portal";
const SCALAR_CDN = `${DEV_PORTAL_BASE}/scalar-api-reference.js`;

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function parseAccountId(req) {
  return req.query.accountid || req.params.accountid || null;
}

function invalidAccountResponse(res, message) {
  return res.status(400).json({
    err: { errcode: "INVALID_ACCOUNT_ID", errdata: null },
    data: null,
    msg: message,
  });
}

function forbiddenAccountResponse(res, message) {
  return res.status(403).json({
    err: { errcode: "FORBIDDEN", errdata: null },
    data: null,
    msg: message,
  });
}

export const swaggerDocs = (app, config, apiDocsSvc, apiserviceSvc) => {
  const buildForAccount = async (accountid) => {
    const rows = await apiDocsSvc.getAccountEndpoints(accountid);
    const demoCredentials =
      await apiserviceSvc.GetDemoAccountCredentials(accountid);
    return buildDynamicSpec(config, rows, demoCredentials);
  };

  const hasDocumentedEndpoints = ({ included }) =>
    included.some(
      (e) =>
        e.endpointid !== "postgeneratetoken" &&
        e.endpointid !== "postrefreshtoken"
    );

  const requireAccountAndBuild = async (req, res) => {
    const accountid = parseAccountId(req);
    if (!accountid || !UUID_RE.test(accountid)) {
      invalidAccountResponse(
        res,
        "Query parameter accountid (UUID) is required"
      );
      return null;
    }

    if (accountid !== req.accountid) {
      forbiddenAccountResponse(
        res,
        "Account ID does not match authenticated session"
      );
      return null;
    }

    const result = await buildForAccount(accountid);
    if (!hasDocumentedEndpoints(result)) {
      res.status(404).json({
        err: {
          errcode: "NO_ENDPOINTS",
          errdata: { accountid, unknown: result.unknown },
        },
        data: null,
        msg: "No documented endpoints found for this account",
      });
      return null;
    }

    return result;
  };

  const devPortalRouter = promiserouter();

  devPortalRouter.get("/scalar-api-reference.js", (req, res) => {
    res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    res.sendFile(
      join(
        __dirname,
        "../node_modules/@scalar/api-reference/dist/browser/standalone.js"
      )
    );
  });

  devPortalRouter.use(AuthenticateAccountToken);

  devPortalRouter.get("/openapi.json", async (req, res) => {
    try {
      const result = await requireAccountAndBuild(req, res);
      if (!result) return;

      const { spec, included, unknown, isDemo } = result;
      res.setHeader("Content-Type", "application/json");
      res.send({
        ...spec,
        "x-included-endpoints": included,
        "x-unknown-endpointids": unknown,
        "x-is-demo-account": isDemo,
      });
    } catch (error) {
      res.status(500).json({
        err: { errcode: "OPENAPI_BUILD_ERROR", errdata: null },
        data: null,
        msg: error.message || "Failed to build OpenAPI spec",
      });
    }
  });

  devPortalRouter.use("/ui", swaggerUi.serve);

  devPortalRouter.get("/ui", async (req, res, next) => {
    try {
      const result = await requireAccountAndBuild(req, res);
      if (!result) return;

      const { spec, isDemo } = result;
      const accountid = parseAccountId(req);
      return swaggerUi.setup(spec, {
        customSiteTitle: `NEMO3 Dev Portal — ${accountid}`,
        swaggerOptions: {
          docExpansion: "list",
          ...(isDemo
            ? {
                defaultModelsExpandDepth: 1,
                tryItOutEnabled: true,
              }
            : {}),
        },
      })(req, res, next);
    } catch (error) {
      return res.status(500).json({
        err: { errcode: "OPENAPI_BUILD_ERROR", errdata: null },
        msg: error.message || "Failed to build OpenAPI spec",
      });
    }
  });

  devPortalRouter.get("/", async (req, res) => {
    try {
      const result = await requireAccountAndBuild(req, res);
      if (!result) return;

      const spec = yaml.dump(result.spec, { lineWidth: -1, noRefs: true });
      const scalarHandler = apiReference({
        theme: "purple",
        cdn: SCALAR_CDN,
        spec: { content: spec },
      });
      return scalarHandler(req, res);
    } catch (error) {
      res.status(500).json({
        err: { errcode: "OPENAPI_BUILD_ERROR", errdata: null },
        data: null,
        msg: error.message || "Failed to build OpenAPI spec",
      });
    }
  });

  app.use(DEV_PORTAL_BASE, devPortalRouter);
};
